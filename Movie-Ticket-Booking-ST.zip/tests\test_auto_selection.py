"""Playwright tests for automatic movie, theatre, date, showtime, and seat selection."""
from __future__ import annotations

import re
from datetime import date

from playwright.sync_api import APIRequestContext, Page, expect

from database import get_connection


def _book_via_ui(page: Page, base_url: str) -> None:
    page.goto(base_url, wait_until="networkidle")
    page.click("#book-my-ticket-btn")
    expect(page.locator("#digital-ticket-card")).to_be_visible(timeout=10000)
    expect(page.locator("#pipeline-state-label")).to_contain_text("Completed", timeout=10000)


def test_01_auto_selects_movie_without_user_input(page: Page, base_url: str) -> None:
    _book_via_ui(page, base_url)
    movie_step = page.locator("#step-val-movie").inner_text().strip()
    assert movie_step and "Waiting" not in movie_step
    assert page.locator("#ticket-movie-title").inner_text().strip() == movie_step


def test_02_auto_selected_movie_exists_in_catalog(
    page: Page, base_url: str, api_context: APIRequestContext
) -> None:
    _book_via_ui(page, base_url)
    chosen_movie = page.locator("#ticket-movie-title").inner_text().strip()
    movies = api_context.get("/api/movies").json()["movies"]
    titles = {m["title"] for m in movies}
    assert chosen_movie in titles


def test_03_auto_selects_highest_rated_unbooked_movie_first(page: Page, base_url: str) -> None:
    _book_via_ui(page, base_url)
    assert page.locator("#ticket-movie-title").inner_text().strip() == "Quantum Echo"


def test_04_auto_selection_rotates_movies_across_bookings(
    page: Page, base_url: str, api_context: APIRequestContext
) -> None:
    r1 = api_context.post("/api/auto-book", data={}).json()["booking"]
    r2 = api_context.post("/api/auto-book", data={}).json()["booking"]
    r3 = api_context.post("/api/auto-book", data={}).json()["booking"]
    assert len({r1["movie_title"], r2["movie_title"], r3["movie_title"]}) == 3


def test_05_auto_selects_available_theatre(page: Page, base_url: str) -> None:
    _book_via_ui(page, base_url)
    theatre_text = page.locator("#ticket-theatre").inner_text().strip()
    screen_type = page.locator("#ticket-screen-type").inner_text().strip()
    assert len(theatre_text) > 3
    assert screen_type in {"IMAX Laser", "Dolby Atmos", "4DX Motion", "Standard Premiere"}


def test_06_auto_selected_theatre_matches_movie_schedule(
    api_context: APIRequestContext, isolated_db
) -> None:
    booking = api_context.post("/api/auto-book", data={}).json()["booking"]
    conn = get_connection(isolated_db)
    try:
        row = conn.execute(
            "SELECT * FROM showtimes WHERE id = ?", (booking["showtime_id"],)
        ).fetchone()
        assert row is not None
        assert row["movie_id"] == booking["movie_id"]
        assert row["theatre_id"] == booking["theatre_id"]
    finally:
        conn.close()


def test_07_auto_selects_valid_booking_date(page: Page, base_url: str) -> None:
    _book_via_ui(page, base_url)
    date_str = page.locator("#ticket-date").inner_text().strip()
    assert re.match(r"^\d{4}-\d{2}-\d{2}$", date_str)
    assert date_str >= date.today().isoformat()


def test_08_auto_selects_earliest_available_date(page: Page, base_url: str) -> None:
    _book_via_ui(page, base_url)
    assert page.locator("#ticket-date").inner_text().strip() == date.today().isoformat()


def test_09_auto_selects_available_showtime(page: Page, base_url: str) -> None:
    _book_via_ui(page, base_url)
    showtime_str = page.locator("#ticket-showtime").inner_text().strip()
    assert showtime_str in {"10:30 AM", "02:15 PM", "06:00 PM", "09:30 PM"}


def test_10_auto_allocates_two_seats_by_default(page: Page, base_url: str) -> None:
    _book_via_ui(page, base_url)
    seats_text = page.locator("#ticket-seats").inner_text().strip()
    seats = [s.strip() for s in seats_text.split(",")]
    assert len(seats) == 2
    assert page.locator("#ticket-seat-count").inner_text().strip() == "2"


def test_11_auto_allocates_adjacent_seats_in_same_row(page: Page, base_url: str) -> None:
    _book_via_ui(page, base_url)
    seats_text = page.locator("#ticket-seats").inner_text().strip()
    assert seats_text == "A1, A2"


def test_12_auto_allocates_next_adjacent_pair_when_first_pair_booked(
    api_context: APIRequestContext, isolated_db
) -> None:
    first = api_context.post("/api/auto-book", data={}).json()["booking"]
    # Book remaining movies once so Quantum Echo becomes eligible again for its next seats
    for _ in range(11):
        api_context.post("/api/auto-book", data={})
    second_quantum = api_context.post("/api/auto-book", data={}).json()["booking"]
    assert second_quantum["movie_title"] == first["movie_title"]
    assert second_quantum["showtime_id"] == first["showtime_id"]
    assert second_quantum["seats"] == ["A3", "A4"]


def test_13_auto_allocates_non_adjacent_seats_when_no_adjacent_pair_remains(
    api_context: APIRequestContext, isolated_db
) -> None:
    conn = get_connection(isolated_db)
    try:
        # Leave only A1 and C4 unbooked on the very first showtime of Quantum Echo (id=12 -> showtime 45)
        st = conn.execute(
            """
            SELECT st.id FROM showtimes st
            JOIN movies m ON m.id = st.movie_id
            WHERE m.title = 'Quantum Echo'
            ORDER BY st.id ASC LIMIT 1
            """
        ).fetchone()
        st_id = st["id"]
        conn.execute(
            "UPDATE seats SET is_booked = 1 WHERE showtime_id = ? AND seat_label NOT IN ('A1', 'C4')",
            (st_id,),
        )
        # Also mark all other showtimes of Quantum Echo full so it picks st_id
        conn.execute(
            """
            UPDATE seats SET is_booked = 1
            WHERE showtime_id IN (
                SELECT st2.id FROM showtimes st2
                JOIN movies m ON m.id = st2.movie_id
                WHERE m.title = 'Quantum Echo' AND st2.id != ?
            )
            """,
            (st_id,),
        )
    finally:
        conn.close()

    booking = api_context.post("/api/auto-book", data={}).json()["booking"]
    assert booking["showtime_id"] == st_id
    assert booking["seats"] == ["A1", "C4"]


def test_14_auto_skips_fully_booked_showtime_and_picks_next_available(
    api_context: APIRequestContext, isolated_db
) -> None:
    conn = get_connection(isolated_db)
    try:
        rows = conn.execute(
            """
            SELECT st.id FROM showtimes st
            JOIN movies m ON m.id = st.movie_id
            WHERE m.title = 'Quantum Echo'
            ORDER BY st.id ASC
            """
        ).fetchall()
        full_st_id = rows[0]["id"]
        conn.execute("UPDATE seats SET is_booked = 1 WHERE showtime_id = ?", (full_st_id,))
    finally:
        conn.close()

    booking = api_context.post("/api/auto-book", data={}).json()["booking"]
    assert booking["movie_title"] == "Quantum Echo"
    assert booking["showtime_id"] != full_st_id
