(() => {
  const bookBtn = document.getElementById("book-my-ticket-btn");
  const statusBanner = document.getElementById("status-banner");
  const pipelineStateLabel = document.getElementById("pipeline-state-label");
  const autoCancelLatestBtn = document.getElementById("auto-cancel-latest-btn");

  const STEP_KEYS = [
    "movie",
    "theatre",
    "date",
    "showtime",
    "seats",
    "pricing",
    "payment",
    "ticket",
  ];

  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  function showBanner(message, type = "success") {
    statusBanner.textContent = message;
    statusBanner.className = `status-banner ${type}`;
    statusBanner.classList.remove("hidden");
  }

  function resetPipeline() {
    STEP_KEYS.forEach((key) => {
      const card = document.querySelector(`.pipeline-step[data-step="${key}"]`);
      const valEl = document.getElementById(`step-val-${key}`);
      if (card) {
        card.classList.remove("active", "done");
      }
      if (valEl) {
        valEl.textContent = "Queued...";
      }
    });
  }

  function renderBarcodeSvg(code) {
    const svg = document.getElementById("ticket-barcode");
    if (!svg) return;
    let bars = "";
    let x = 8;
    for (let i = 0; i < code.length; i += 1) {
      const charCode = code.charCodeAt(i);
      const width = (charCode % 3) + 2;
      bars += `<rect x="${x}" y="6" width="${width}" height="52" fill="#0f172a" />`;
      x += width + ((charCode % 2) + 2);
      if (x > 168) break;
    }
    svg.innerHTML = bars;
  }

  function renderDigitalTicket(booking) {
    const emptyState = document.getElementById("ticket-empty-state");
    const card = document.getElementById("digital-ticket-card");
    emptyState.classList.add("hidden");
    card.classList.remove("hidden");
    card.dataset.bookingId = booking.booking_id;

    document.getElementById("ticket-poster").src =
      booking.poster_url || "/static/posters/poster_01.svg";
    document.getElementById("ticket-booking-id").textContent = booking.booking_id;
    document.getElementById("ticket-movie-title").textContent = booking.movie_title;
    document.getElementById("ticket-movie-meta").textContent = `${
      booking.genre || "Feature Film"
    } • ${booking.rating || "PG-13"} • ${booking.duration_mins || 120}m`;
    document.getElementById("ticket-theatre").textContent = `${booking.theatre_name} (${booking.theatre_location})`;
    document.getElementById("ticket-screen-type").textContent = booking.screen_type;
    document.getElementById("ticket-date").textContent = booking.show_date;
    document.getElementById("ticket-showtime").textContent = booking.show_time;
    document.getElementById("ticket-seats").textContent = (booking.seats || []).join(", ");
    document.getElementById("ticket-payment-id").textContent = booking.payment_id;
    document.getElementById("ticket-seat-count").textContent = booking.seat_count;
    document.getElementById("ticket-unit-price").textContent = Number(booking.unit_price).toFixed(2);
    document.getElementById("ticket-subtotal").textContent = `$${Number(booking.ticket_price).toFixed(2)}`;
    document.getElementById("ticket-fee").textContent = `$${Number(booking.convenience_fee).toFixed(2)}`;
    document.getElementById("ticket-tax").textContent = `$${Number(booking.tax_amount).toFixed(2)}`;
    document.getElementById("ticket-total").textContent = `$${Number(booking.total_amount).toFixed(2)}`;
    document.getElementById("ticket-payment-status").textContent = booking.payment_status;
    document.getElementById("stub-seat-count").textContent = booking.seat_count;
    document.getElementById("stub-booking-code").textContent = booking.booking_id;
    document.getElementById("ticket-created-at").textContent = `Booked: ${booking.created_at}`;

    const badge = document.getElementById("ticket-status-badge");
    badge.textContent = booking.booking_status;
    badge.classList.toggle("cancelled", booking.booking_status === "CANCELLED");

    const cancelBtn = document.getElementById("ticket-cancel-btn");
    cancelBtn.disabled = booking.booking_status === "CANCELLED";
    cancelBtn.textContent =
      booking.booking_status === "CANCELLED" ? "Booking Cancelled" : "Cancel This Booking";
    cancelBtn.dataset.bookingId = booking.booking_id;

    renderBarcodeSvg(booking.booking_id);
  }

  function renderHistory(bookings) {
    const emptyEl = document.getElementById("history-empty-state");
    const listEl = document.getElementById("history-list");

    if (!bookings || bookings.length === 0) {
      emptyEl.classList.remove("hidden");
      listEl.innerHTML = "";
      return;
    }

    emptyEl.classList.add("hidden");
    listEl.innerHTML = bookings
      .map((b) => {
        const isConfirmed = b.booking_status === "CONFIRMED";
        const chipClass = isConfirmed ? "chip-confirmed" : "chip-cancelled";
        const cancelButtonHtml = isConfirmed
          ? `<button class="btn-danger btn-cancel-booking" type="button" data-booking-id="${b.booking_id}">Cancel Booking</button>`
          : "";

        return `
          <div class="history-item" data-booking-id="${b.booking_id}">
            <div class="history-main">
              <div class="history-top">
                <span class="history-id">${b.booking_id}</span>
                <span class="status-chip ${chipClass}">${b.booking_status}</span>
              </div>
              <div class="history-title">${b.movie_title} &mdash; ${b.theatre_name}</div>
              <div class="history-sub">
                Date: <strong>${b.show_date}</strong> &bull;
                Time: <strong>${b.show_time}</strong> &bull;
                Seats: <strong>${(b.seats || []).join(", ")}</strong> &bull;
                Total: <strong>$${Number(b.total_amount).toFixed(2)}</strong>
              </div>
            </div>
            <div class="history-buttons">
              <button class="btn-secondary btn-view-ticket" type="button" data-booking-id="${b.booking_id}">View Ticket</button>
              ${cancelButtonHtml}
            </div>
          </div>
        `;
      })
      .join("");
  }

  async function refreshLiveData() {
    const [statusRes, bookingsRes, moviesRes] = await Promise.all([
      fetch("/api/system-status"),
      fetch("/api/bookings"),
      fetch("/api/movies"),
    ]);

    if (statusRes.ok) {
      const s = await statusRes.json();
      document.getElementById("stat-movies").textContent = s.movies_count;
      document.getElementById("stat-theatres").textContent = s.theatres_count;
      document.getElementById("stat-showtimes").textContent = s.showtimes_count;
      document.getElementById("stat-seats").textContent = s.available_seats;
      document.getElementById("stat-confirmed").textContent = s.confirmed_bookings;
      document.getElementById("stat-cancelled").textContent = s.cancelled_bookings;
    }

    if (bookingsRes.ok) {
      const data = await bookingsRes.json();
      renderHistory(data.bookings || []);
    }

    if (moviesRes.ok) {
      const mData = await moviesRes.json();
      (mData.movies || []).forEach((movie) => {
        const card = document.querySelector(`.movie-card[data-movie-id="${movie.id}"]`);
        if (card) {
          const pill = card.querySelector(".avail-pill");
          if (pill) pill.textContent = `${movie.available_seats} seats open`;
        }
      });
    }
  }

  async function runAutoBooking() {
    bookBtn.disabled = true;
    statusBanner.classList.add("hidden");
    resetPipeline();
    pipelineStateLabel.textContent = "Running autonomous booking workflow...";

    try {
      const apiPromise = fetch("/api/auto-book", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });

      // Animate early stages while API executes
      for (let i = 0; i < 3; i += 1) {
        const key = STEP_KEYS[i];
        const card = document.querySelector(`.pipeline-step[data-step="${key}"]`);
        if (card) card.classList.add("active");
        await sleep(90);
      }

      const response = await apiPromise;
      const payload = await response.json();

      if (!response.ok) {
        throw new Error(payload.error || "Automatic booking failed.");
      }

      const stepMap = {};
      (payload.workflow_steps || []).forEach((item) => {
        stepMap[item.key] = item.value;
      });

      for (const key of STEP_KEYS) {
        const card = document.querySelector(`.pipeline-step[data-step="${key}"]`);
        const valEl = document.getElementById(`step-val-${key}`);
        if (card) {
          card.classList.add("active");
        }
        await sleep(90);
        if (card) {
          card.classList.remove("active");
          card.classList.add("done");
        }
        if (valEl) {
          valEl.textContent = stepMap[key] || "Completed";
        }
      }

      const booking = payload.booking;
      pipelineStateLabel.textContent = `Completed — Ticket ${booking.booking_id} issued!`;
      renderDigitalTicket(booking);
      await refreshLiveData();
      showBanner(
        `Ticket ${booking.booking_id} booked automatically for ${booking.movie_title} (${booking.seats.join(", ")}).`,
        "success"
      );
    } catch (err) {
      pipelineStateLabel.textContent = "Workflow halted";
      showBanner(err.message || "Unable to complete automatic booking.", "error");
    } finally {
      bookBtn.disabled = false;
    }
  }

  async function handleCancelBooking(bookingId) {
    if (!bookingId) return;
    try {
      const res = await fetch(`/api/bookings/${encodeURIComponent(bookingId)}/cancel`, {
        method: "POST",
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Cancellation failed.");
      }

      const currentCardId = document.getElementById("digital-ticket-card").dataset.bookingId;
      if (currentCardId === bookingId) {
        renderDigitalTicket(data.booking);
      }
      await refreshLiveData();
      showBanner(
        `Booking ${bookingId} cancelled automatically. Seats released and payment refunded.`,
        "success"
      );
    } catch (err) {
      showBanner(err.message || "Cancellation failed.", "error");
    }
  }

  async function handleAutoCancelLatest() {
    try {
      const res = await fetch("/api/bookings/cancel-latest", { method: "POST" });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "No confirmed bookings to cancel.");
      }
      const currentCardId = document.getElementById("digital-ticket-card").dataset.bookingId;
      if (currentCardId === data.booking.booking_id) {
        renderDigitalTicket(data.booking);
      }
      await refreshLiveData();
      showBanner(
        `Latest booking ${data.booking.booking_id} cancelled automatically.`,
        "success"
      );
    } catch (err) {
      showBanner(err.message || "Unable to auto-cancel latest booking.", "error");
    }
  }

  bookBtn.addEventListener("click", runAutoBooking);

  document.getElementById("ticket-cancel-btn").addEventListener("click", (e) => {
    const id = e.currentTarget.dataset.bookingId;
    handleCancelBooking(id);
  });

  if (autoCancelLatestBtn) {
    autoCancelLatestBtn.addEventListener("click", handleAutoCancelLatest);
  }

  document.getElementById("history-list").addEventListener("click", async (e) => {
    const viewBtn = e.target.closest(".btn-view-ticket");
    if (viewBtn) {
      const id = viewBtn.dataset.bookingId;
      const res = await fetch(`/api/bookings/${encodeURIComponent(id)}`);
      if (res.ok) {
        const data = await res.json();
        renderDigitalTicket(data.booking);
        document.getElementById("digital-ticket-section").scrollIntoView({ behavior: "smooth" });
      }
      return;
    }

    const cancelBtn = e.target.closest(".btn-cancel-booking");
    if (cancelBtn) {
      handleCancelBooking(cancelBtn.dataset.bookingId);
    }
  });

  // --- Testing Results Dashboard ---
  let cachedTestCases = [];
  let activeStatusFilter = "ALL";

  const runAllTestsBtn = document.getElementById("run-all-tests-btn");
  const testRunnerBanner = document.getElementById("test-runner-banner");
  const testDetailModal = document.getElementById("test-detail-modal");
  const modalCloseBtn = document.getElementById("modal-close-btn");

  function showTestBanner(msg, type = "success") {
    if (!testRunnerBanner) return;
    testRunnerBanner.textContent = msg;
    testRunnerBanner.className = `status-banner ${type}`;
    testRunnerBanner.classList.remove("hidden");
  }

  function escapeHtml(str) {
    return String(str || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function renderTestDashboard(data) {
    cachedTestCases = data.cases || [];
    document.getElementById("test-stat-total").textContent = data.total ?? 0;
    document.getElementById("test-stat-passed").textContent = data.passed ?? 0;
    document.getElementById("test-stat-failed").textContent = data.failed ?? 0;
    document.getElementById("test-stat-skipped").textContent = data.skipped ?? 0;
    document.getElementById("test-stat-pass-rate").textContent = `${data.pass_percentage ?? 0}%`;
    document.getElementById("test-executed-at").textContent = data.executed_at || "-";
    document.getElementById("test-total-duration").textContent = `${data.total_duration_sec ?? 0}s`;

    const allPill = document.querySelector('[data-status-filter="ALL"]');
    const passPill = document.querySelector('[data-status-filter="PASS"]');
    const failPill = document.querySelector('[data-status-filter="FAIL"]');
    const skipPill = document.querySelector('[data-status-filter="SKIPPED"]');
    if (allPill) allPill.textContent = `All (${data.total ?? 0})`;
    if (passPill) passPill.textContent = `PASS (${data.passed ?? 0})`;
    if (failPill) failPill.textContent = `FAIL (${data.failed ?? 0})`;
    if (skipPill) skipPill.textContent = `SKIPPED (${data.skipped ?? 0})`;

    renderFilteredTestRows();
  }

  function renderFilteredTestRows() {
    const tbody = document.getElementById("test-results-tbody");
    if (!tbody) return;
    const filtered = cachedTestCases.filter(
      (tc) => activeStatusFilter === "ALL" || tc.status === activeStatusFilter
    );

    tbody.innerHTML = filtered
      .map((tc) => {
        const statusLower = (tc.status || "SKIPPED").toLowerCase();
        const failureBlock = tc.failure_reason
          ? `<div class="tc-failure-inline">${escapeHtml(tc.failure_reason)}</div>`
          : "";
        return `
          <tr data-status="${escapeHtml(tc.status)}" data-test-id="${escapeHtml(tc.test_id)}">
            <td class="tc-id">${escapeHtml(tc.test_id)}</td>
            <td class="tc-scenario">${escapeHtml(tc.scenario)}</td>
            <td class="tc-desc">${escapeHtml(tc.description)}</td>
            <td class="tc-expected">${escapeHtml(tc.expected_result)}</td>
            <td class="tc-actual">${escapeHtml(tc.actual_result)}${failureBlock}</td>
            <td>
              <span class="tc-status-badge status-${statusLower}">
                <span class="status-dot"></span>${escapeHtml(tc.status)}
              </span>
            </td>
            <td class="tc-duration">${Number(tc.duration_sec || 0).toFixed(3)}s</td>
            <td>
              <button class="btn-secondary btn-view-test-detail" type="button" data-test-id="${escapeHtml(tc.test_id)}">
                View Details
              </button>
            </td>
          </tr>
        `;
      })
      .join("");
  }

  async function refreshTestDashboard() {
    const res = await fetch("/api/tests/results");
    if (res.ok) {
      const data = await res.json();
      renderTestDashboard(data);
    }
  }

  function openTestDetailModal(testId) {
    const tc = cachedTestCases.find((item) => item.test_id === testId);
    if (!tc || !testDetailModal) return;

    document.getElementById("modal-test-id").textContent = tc.test_id;
    document.getElementById("modal-test-title").textContent = tc.scenario;
    document.getElementById("modal-duration").textContent = `${Number(tc.duration_sec || 0).toFixed(3)}s`;
    document.getElementById("modal-fn-name").textContent = tc.function_name || "-";
    document.getElementById("modal-description").textContent = tc.description || "-";
    document.getElementById("modal-expected").textContent = tc.expected_result || "-";
    document.getElementById("modal-actual").textContent = tc.actual_result || "-";

    const badge = document.getElementById("modal-status-badge");
    badge.className = `tc-status-badge status-${(tc.status || "SKIPPED").toLowerCase()}`;
    badge.innerHTML = `<span class="status-dot"></span>${escapeHtml(tc.status)}`;

    const failBox = document.getElementById("modal-failure-box");
    const failReason = document.getElementById("modal-failure-reason");
    if (tc.failure_reason) {
      failReason.textContent = tc.failure_reason;
      failBox.classList.remove("hidden");
    } else {
      failBox.classList.add("hidden");
    }

    const shotBox = document.getElementById("modal-screenshot-box");
    const shotImg = document.getElementById("modal-screenshot-img");
    if (tc.screenshot_url) {
      shotImg.src = tc.screenshot_url;
      shotBox.classList.remove("hidden");
    } else {
      shotImg.src = "";
      shotBox.classList.add("hidden");
    }

    testDetailModal.classList.remove("hidden");
  }

  async function triggerRunAllTests() {
    if (!runAllTestsBtn) return;
    runAllTestsBtn.disabled = true;
    runAllTestsBtn.textContent = "Running All Playwright Tests...";
    showTestBanner("Executing Playwright test suite... dashboard will refresh automatically on completion.", "success");

    try {
      const res = await fetch("/api/tests/run", { method: "POST" });
      const data = await res.json();
      if (!res.ok && res.status !== 409) {
        throw new Error(data.message || data.error || "Unable to start test runner.");
      }

      // Poll until test suite completes
      while (true) {
        await sleep(1500);
        const statusRes = await fetch("/api/tests/status");
        if (!statusRes.ok) break;
        const st = await statusRes.json();
        if (!st.running) {
          await refreshTestDashboard();
          const bannerType = st.last_exit_code === 0 ? "success" : "error";
          showTestBanner(
            `${st.message} Dashboard refreshed automatically (${st.finished_at || "now"}).`,
            bannerType
          );
          break;
        }
      }
    } catch (err) {
      showTestBanner(err.message || "Failed to execute test suite.", "error");
    } finally {
      runAllTestsBtn.disabled = false;
      runAllTestsBtn.textContent = "Run All Tests";
    }
  }

  if (runAllTestsBtn) {
    runAllTestsBtn.addEventListener("click", triggerRunAllTests);
  }

  document.querySelectorAll(".filter-pill").forEach((pill) => {
    pill.addEventListener("click", () => {
      document.querySelectorAll(".filter-pill").forEach((p) => p.classList.remove("active"));
      pill.classList.add("active");
      activeStatusFilter = pill.dataset.statusFilter || "ALL";
      renderFilteredTestRows();
    });
  });

  const testTbody = document.getElementById("test-results-tbody");
  if (testTbody) {
    testTbody.addEventListener("click", (e) => {
      const detailBtn = e.target.closest(".btn-view-test-detail");
      if (detailBtn) {
        openTestDetailModal(detailBtn.dataset.testId);
      }
    });
  }

  if (modalCloseBtn && testDetailModal) {
    modalCloseBtn.addEventListener("click", () => {
      testDetailModal.classList.add("hidden");
    });
    testDetailModal.addEventListener("click", (e) => {
      if (e.target === testDetailModal) {
        testDetailModal.classList.add("hidden");
      }
    });
  }

  refreshTestDashboard();
})();
