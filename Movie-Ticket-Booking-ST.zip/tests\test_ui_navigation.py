"""Playwright tests for UI rendering, posters, zero manual selection controls, navigation, and responsiveness."""
from __future__ import annotations

from playwright.sync_api import APIRequestContext, Page, expect


def test_47_homepage_loads_with_title_and_zero_console_errors(page: Page, base_url: str) -> None:
    errors = []
    page.on("pageerror", lambda exc: errors.append(str(exc)))
    page.on("console", lambda msg: errors.append(msg.text) if msg.type == "error" else None)

    page.goto(base_url, wait_until="networkidle")
    expect(page).to_have_title("CineAuto — Automatic One-Click Movie Ticket Booking")
    assert errors == []


def test_48_at_least_10_movies_displayed_with_details(page: Page, base_url: str) -> None:
    page.goto(base_url, wait_until="networkidle")
    cards = page.locator("#movies-grid .movie-card")
    assert cards.count() >= 10
    first = cards.first
    assert first.locator("h3").inner_text().strip() != ""
    assert "$" in first.locator(".movie-price-tag").inner_text()
    assert "seats open" in first.locator(".avail-pill").inner_text()


def test_49_all_movie_posters_load_cleanly(page: Page, base_url: str) -> None:
    page.goto(base_url, wait_until="networkidle")
    loaded = page.evaluate(
        """() => {
            const imgs = Array.from(document.querySelectorAll('#movies-grid img'));
            return imgs.map(img => ({ src: img.src, complete: img.complete, width: img.naturalWidth }));
        }"""
    )
    assert len(loaded) >= 10
    for item in loaded:
        assert item["complete"] is True and item["width"] > 0, f"Broken poster: {item}"


def test_50_zero_manual_selection_controls_in_ui(page: Page, base_url: str) -> None:
    page.goto(base_url, wait_until="networkidle")
    assert page.locator("select").count() == 0
    assert page.locator("input").count() == 0
    assert page.locator("textarea").count() == 0
    assert page.locator("form").count() == 0


def test_51_only_one_booking_action_button_book_my_ticket(page: Page, base_url: str) -> None:
    page.goto(base_url, wait_until="networkidle")
    btn = page.locator("#book-my-ticket-btn")
    expect(btn).to_be_visible()
    expect(btn).to_be_enabled()
    expect(btn).to_contain_text("BOOK MY TICKET")
    assert page.locator(".hero-actions button").count() == 1


def test_52_navbar_anchor_navigation_links_work(page: Page, base_url: str) -> None:
    page.goto(base_url, wait_until="networkidle")
    for href, section_id in (
        ("#movies-section", "#movies-section"),
        ("#workflow-section", "#workflow-section"),
        ("#digital-ticket-section", "#digital-ticket-section"),
        ("#booking-history-section", "#booking-history-section"),
    ):
        page.locator(f".nav-links a[href='{href}']").click()
        expect(page.locator(section_id)).to_be_visible()


def test_53_booking_history_view_ticket_button_loads_ticket(
    page: Page, base_url: str, api_context: APIRequestContext
) -> None:
    b1 = api_context.post("/api/auto-book", data={}).json()["booking"]
    api_context.post("/api/auto-book", data={})

    page.goto(base_url, wait_until="networkidle")
    row = page.locator(f".history-item[data-booking-id='{b1['booking_id']}']")
    row.locator(".btn-view-ticket").click()

    expect(page.locator("#digital-ticket-card")).to_be_visible()
    expect(page.locator("#ticket-booking-id")).to_have_text(b1["booking_id"])
    expect(page.locator("#ticket-movie-title")).to_have_text(b1["movie_title"])


def test_54_live_stats_cards_update_after_book_and_cancel(page: Page, base_url: str) -> None:
    page.goto(base_url, wait_until="networkidle")
    initial_seats = int(page.locator("#stat-seats").inner_text())

    page.click("#book-my-ticket-btn")
    expect(page.locator("#stat-confirmed")).to_have_text("1", timeout=10000)
    expect(page.locator("#stat-seats")).to_have_text(str(initial_seats - 2))

    page.click("#ticket-cancel-btn")
    expect(page.locator("#stat-confirmed")).to_have_text("0", timeout=10000)
    expect(page.locator("#stat-cancelled")).to_have_text("1")
    expect(page.locator("#stat-seats")).to_have_text(str(initial_seats))


def test_55_auto_cancel_latest_when_empty_shows_error_banner(page: Page, base_url: str) -> None:
    page.goto(base_url, wait_until="networkidle")
    page.click("#auto-cancel-latest-btn")
    banner = page.locator("#status-banner")
    expect(banner).to_be_visible()
    assert "error" in (banner.get_attribute("class") or "")


def test_56_responsive_mobile_viewport_renders_without_horizontal_overflow(
    page: Page, base_url: str
) -> None:
    page.set_viewport_size({"width": 375, "height": 812})
    page.goto(base_url, wait_until="networkidle")
    expect(page.locator("#book-my-ticket-btn")).to_be_visible()
    overflow = page.evaluate("() => document.documentElement.scrollWidth - window.innerWidth")
    assert overflow <= 2


def test_57_testing_dashboard_displays_summary_metrics(page: Page, base_url: str) -> None:
    page.goto(base_url, wait_until="networkidle")
    section = page.locator("#testing-results-dashboard")
    expect(section).to_be_visible()
    for selector in (
        "#test-stat-total",
        "#test-stat-passed",
        "#test-stat-failed",
        "#test-stat-skipped",
        "#test-stat-pass-rate",
        "#run-all-tests-btn",
        "#download-html-report-btn",
        "#download-pdf-report-btn",
    ):
        expect(page.locator(selector)).to_be_visible()


def test_58_testing_dashboard_lists_all_individual_test_cases(page: Page, base_url: str) -> None:
    page.goto(base_url, wait_until="networkidle")
    rows = page.locator("#test-results-tbody tr")
    assert rows.count() >= 50
    first_row = rows.first
    expect(first_row.locator(".tc-id")).to_contain_text("TC-")
    expect(first_row.locator(".tc-status-badge")).to_be_visible()
    expect(first_row.locator(".tc-duration")).to_contain_text("s")


def test_59_testing_dashboard_view_details_modal_opens(page: Page, base_url: str) -> None:
    page.goto(base_url, wait_until="networkidle")
    page.locator("#test-results-tbody .btn-view-test-detail").first.click()
    modal = page.locator("#test-detail-modal")
    expect(modal).to_be_visible()
    expect(page.locator("#modal-test-id")).to_contain_text("TC-")
    expect(page.locator("#modal-expected")).not_to_be_empty()
    page.click("#modal-close-btn")
    expect(modal).to_be_hidden()


def test_60_downloadable_html_and_pdf_reports_return_valid_files(
    api_context: APIRequestContext,
) -> None:
    html_res = api_context.get("/api/tests/report/html")
    assert html_res.status == 200
    assert "text/html" in html_res.headers.get("content-type", "")
    assert len(html_res.body()) > 500

    pdf_res = api_context.get("/api/tests/report/pdf")
    assert pdf_res.status == 200
    assert "application/pdf" in pdf_res.headers.get("content-type", "")
    assert pdf_res.body()[:5] == b"%PDF-"
