# Manual Test Case Documentation — CineAuto Movie Ticket Booking System

**Project:** CineAuto — Automatic One-Click Movie Ticket Booking System  
**Tech Stack:** Python 3.10, Flask, HTML5, CSS3, JavaScript, SQLite3, Playwright  
**Total Test Cases:** 60  

---

## 1. Automatic Movie, Theatre, Date, Showtime & Seat Selection (TC-01 – TC-14)

| Test ID | Test Case Title | Preconditions | Test Steps | Expected Result | Automated Ref |
|---|---|---|---|---|---|
| TC-01 | Auto-select movie without user input | App open with seeded DB | 1. Open `/` 2. Click `BOOK MY TICKET` | Pipeline Step 1 populates an active movie matching the ticket title | `test_01_auto_selects_movie_without_user_input` |
| TC-02 | Auto-selected movie exists in catalog | App running | 1. Book ticket via UI 2. Compare ticket title against `/api/movies` | Chosen movie belongs to active catalog | `test_02_auto_selected_movie_exists_in_catalog` |
| TC-03 | Highest-rated unbooked movie selected first | Fresh seeded DB | 1. Open `/` 2. Click `BOOK MY TICKET` | First booking selects `Quantum Echo` (IMDb 9.0) | `test_03_auto_selects_highest_rated_unbooked_movie_first` |
| TC-04 | Auto-selection rotates movies across bookings | Fresh seeded DB | 1. Trigger 3 consecutive auto-bookings | 3 distinct movies are automatically selected | `test_04_auto_selection_rotates_movies_across_bookings` |
| TC-05 | Auto-select available theatre | Fresh seeded DB | 1. Click `BOOK MY TICKET` 2. Inspect theatre & screen format | Valid partner theatre and screen type (`IMAX Laser`, `Dolby Atmos`, `4DX Motion`, or `Standard Premiere`) shown | `test_05_auto_selects_available_theatre` |
| TC-06 | Auto-selected theatre matches movie schedule | Seeded `showtimes` | 1. Call `POST /api/auto-book` 2. Query `showtimes` table | `showtimes.movie_id` and `theatre_id` match booking | `test_06_auto_selected_theatre_matches_movie_schedule` |
| TC-07 | Auto-select valid booking date | Fresh seeded DB | 1. Click `BOOK MY TICKET` 2. Inspect `#ticket-date` | Date matches `YYYY-MM-DD` and `>= today` | `test_07_auto_selects_valid_booking_date` |
| TC-08 | Auto-select earliest available date | Fresh seeded DB | 1. Click `BOOK MY TICKET` | Earliest open date (today) is selected | `test_08_auto_selects_earliest_available_date` |
| TC-09 | Auto-select available showtime | Fresh seeded DB | 1. Click `BOOK MY TICKET` 2. Inspect `#ticket-showtime` | Valid showtime slot (`10:30 AM` / `02:15 PM` etc.) shown | `test_09_auto_selects_available_showtime` |
| TC-10 | Auto-allocate two seats by default | Fresh seeded DB | 1. Click `BOOK MY TICKET` | Exactly 2 seats allocated and displayed | `test_10_auto_allocates_two_seats_by_default` |
| TC-11 | Auto-allocate adjacent seats in same row | Empty showtime | 1. Click `BOOK MY TICKET` | Adjacent seats `A1, A2` allocated | `test_11_auto_allocates_adjacent_seats_in_same_row` |
| TC-12 | Auto-allocate next adjacent pair | `A1, A2` booked | 1. Book all movies once 2. Book Quantum Echo again | Next adjacent pair `A3, A4` allocated | `test_12_auto_allocates_next_adjacent_pair_when_first_pair_booked` |
| TC-13 | Fallback to non-adjacent available seats | Only `A1`, `C4` open | 1. Mark all other seats booked for target movie 2. Auto-book | Allocates remaining open seats `A1, C4` | `test_13_auto_allocates_non_adjacent_seats_when_no_adjacent_pair_remains` |
| TC-14 | Skip sold-out showtime automatically | First showtime full | 1. Mark first showtime's seats booked 2. Auto-book | System automatically selects next available showtime | `test_14_auto_skips_fully_booked_showtime_and_picks_next_available` |

---

## 2. Automatic Pricing, Payment & Ticket Generation (TC-15 – TC-26)

| Test ID | Test Case Title | Preconditions | Test Steps | Expected Result | Automated Ref |
|---|---|---|---|---|---|
| TC-15 | Calculate unit price & ticket subtotal | Fresh DB | 1. Click `BOOK MY TICKET` 2. Compare `unit_price * seat_count` vs subtotal | Exact match to 2 decimal places | `test_15_auto_calculates_unit_and_ticket_subtotal` |
| TC-16 | Calculate convenience fee ($1.50/seat) | Fresh DB | 1. Click `BOOK MY TICKET` 2. Check `#ticket-fee` | Equals `1.50 * seat_count` | `test_16_auto_calculates_convenience_fee` |
| TC-17 | Calculate 18% GST tax | Fresh DB | 1. Click `BOOK MY TICKET` 2. Check `#ticket-tax` | Equals `round((subtotal + fee) * 0.18, 2)` | `test_17_auto_calculates_18_percent_tax` |
| TC-18 | Calculate grand total | Fresh DB | 1. Click `BOOK MY TICKET` 2. Check `#ticket-total` | Equals `subtotal + fee + tax` | `test_18_auto_calculates_grand_total_displayed_on_ticket` |
| TC-19 | Pricing for 1 seat | API available | 1. `POST /api/auto-book` with `{"seat_count": 1}` | Fee `$1.50`, accurate tax and total | `test_19_auto_pricing_for_single_seat_via_api` |
| TC-20 | Pricing for 6 seats | API available | 1. `POST /api/auto-book` with `{"seat_count": 6}` | 6 seats, fee `$9.00`, accurate tax and total | `test_20_auto_pricing_for_six_seats_via_api` |
| TC-21 | Simulated auto-payment completes | Fresh DB | 1. Click `BOOK MY TICKET` | Payment ID `PAY-YYYYMMDD-XXXXXXXX` and status `PAID` shown | `test_21_simulated_payment_completes_automatically` |
| TC-22 | Unique booking & payment IDs | Fresh DB | 1. Create 5 bookings | 5 unique `CINE-...` and 5 unique `PAY-...` IDs generated | `test_22_unique_booking_ids_across_multiple_bookings` |
| TC-23 | Confirmation banner displayed | Fresh DB | 1. Click `BOOK MY TICKET` | Success banner appears containing booking ID | `test_23_booking_confirmation_banner_displayed` |
| TC-24 | Digital ticket displays all fields | Fresh DB | 1. Click `BOOK MY TICKET` | Poster, `CONFIRMED` badge, metadata, seats, breakdown, timestamp visible | `test_24_digital_ticket_displays_all_booking_fields` |
| TC-25 | Digital ticket renders barcode SVG | Fresh DB | 1. Click `BOOK MY TICKET` | `#ticket-barcode` renders `>= 10` SVG `<rect>` bars | `test_25_digital_ticket_renders_barcode_svg` |
| TC-26 | Animated pipeline marks all 8 steps done | Fresh DB | 1. Click `BOOK MY TICKET` | All 8 `.pipeline-step` cards transition to `.done` | `test_26_pipeline_updates_all_eight_steps_to_done` |

---

## 3. Duplicate Prevention, Cancellation & Invalid Scenarios (TC-27 – TC-38)

| Test ID | Test Case Title | Preconditions | Test Steps | Expected Result | Automated Ref |
|---|---|---|---|---|---|
| TC-27 | Prevent duplicate seat booking | Seat `A1` booked | 1. Reserve `A1, A2` on showtime 1 2. Reserve `A1` again | Second request returns HTTP `409 Conflict` | `test_27_duplicate_seat_booking_prevented_via_api` |
| TC-28 | Atomic rollback on partial overlap | `B1, B2` booked | 1. Attempt to reserve `B2, B3` | Returns `409`; `B3` remains `is_booked = 0` | `test_28_partial_seat_overlap_prevented` |
| TC-29 | Sequential auto-bookings never collide | Fresh DB | 1. Run 12 consecutive auto-bookings | Zero overlapping `(showtime_id, seat_label)` pairs | `test_29_sequential_auto_bookings_never_assign_duplicate_seats` |
| TC-30 | Cancel booking via digital ticket button | 1 confirmed booking | 1. Click `#ticket-cancel-btn` | Badge becomes `CANCELLED`, payment `REFUNDED`, button disabled | `test_30_cancel_booking_from_digital_ticket_button` |
| TC-31 | Cancel booking via history row button | 1 confirmed booking | 1. Click `.btn-cancel-booking` in history | History chip becomes `CANCELLED`, cancel button removed | `test_31_cancel_booking_from_history_row_button` |
| TC-32 | Auto-cancel latest booking button | 2 confirmed bookings | 1. Click `#auto-cancel-latest-btn` | Only newest booking cancelled; older stays `CONFIRMED` | `test_32_auto_cancel_latest_button_cancels_newest_confirmed` |
| TC-33 | Cancellation frees seats for rebooking | `A1, A2` booked | 1. Cancel booking 2. Reserve `A1, A2` again | Re-reservation succeeds with HTTP `201` | `test_33_cancellation_releases_seats_for_rebooking` |
| TC-34 | Double cancellation rejected | Booking cancelled | 1. Call `POST /api/bookings/<id>/cancel` again | Returns HTTP `409` ("already cancelled") | `test_34_double_cancellation_returns_409_error` |
| TC-35 | Cancel nonexistent booking rejected | Any | 1. `POST /api/bookings/CINE-NONEXISTENT-9999/cancel` | Returns HTTP `404` | `test_35_cancel_nonexistent_booking_returns_404` |
| TC-36 | Get nonexistent booking rejected | Any | 1. `GET /api/bookings/DOES-NOT-EXIST` | Returns HTTP `404` | `test_36_get_nonexistent_booking_returns_404` |
| TC-37 | Invalid `seat_count` values rejected | Any | 1. Post `0`, `-2`, `7`, `"two"`, `True` to `/api/auto-book` | All return HTTP `400` | `test_37_invalid_seat_count_values_rejected` |
| TC-38 | Sold-out scenario displays UI error banner | All seats marked booked | 1. Click `BOOK MY TICKET` | Red error banner displays gracefully without UI crash | `test_38_sold_out_all_showtimes_shows_error_banner_in_ui` |

---

## 4. Database Operations & Integrity (TC-39 – TC-46)

| Test ID | Test Case Title | Preconditions | Test Steps | Expected Result | Automated Ref |
|---|---|---|---|---|---|
| TC-39 | Required SQLite tables created | Fresh DB | 1. Query `sqlite_master` | `movies`, `theatres`, `showtimes`, `seats`, `bookings`, `booking_seats` exist | `test_39_database_initializes_all_required_tables` |
| TC-40 | Seed data counts verified | Fresh DB | 1. Count rows across tables | `>=10` movies (12), `>=4` theatres, 24 seats per showtime | `test_40_database_seeds_at_least_10_movies_and_theatres` |
| TC-41 | Booking persists across page reload | 1 booking created | 1. Book via UI 2. Reload page | Booking visible in history; confirmed stat = `1` | `test_41_booking_persists_across_browser_reload` |
| TC-42 | Cancellation persists across page reload | 1 booking cancelled | 1. Cancel via UI 2. Reload page | History shows `CANCELLED`; cancelled stat = `1` | `test_42_cancellation_persists_across_browser_reload` |
| TC-43 | `UNIQUE(showtime_id, seat_label)` enforced | Active booking exists | 1. Attempt raw SQLite insert of same seat | Raises `sqlite3.IntegrityError` | `test_43_unique_constraint_on_booking_seats_table` |
| TC-44 | `UNIQUE(booking_id)` enforced | Active booking exists | 1. Attempt raw SQLite insert with duplicate `booking_id` | Raises `sqlite3.IntegrityError` | `test_44_unique_constraint_on_booking_id_column` |
| TC-45 | Available seat count tracks book/cancel | Fresh DB | 1. Check status -> book 2 seats -> check -> cancel -> check | Decrements by 2 on book, increments by 2 on cancel | `test_45_seat_availability_count_decrements_and_increments` |
| TC-46 | Malformed API JSON rejected | Any | 1. Send array JSON / non-int `showtime_id` | Returns HTTP `400` | `test_46_invalid_json_body_rejected_cleanly` |

---

## 5. UI, Posters, Zero-Manual-Selection & Navigation (TC-47 – TC-56)

| Test ID | Test Case Title | Preconditions | Test Steps | Expected Result | Automated Ref |
|---|---|---|---|---|---|
| TC-47 | Homepage loads with zero JS errors | Server running | 1. Navigate to `/` while listening for `console`/`pageerror` | Title matches, zero JS errors | `test_47_homepage_loads_with_title_and_zero_console_errors` |
| TC-48 | At least 10 movies displayed | Fresh DB | 1. Count `#movies-grid .movie-card` | `>= 10` cards (12) with title, price, open seats | `test_48_at_least_10_movies_displayed_with_details` |
| TC-49 | All movie posters load without broken images | Fresh DB | 1. Inspect `img.complete` and `naturalWidth` | All 12 posters load with `naturalWidth > 0` | `test_49_all_movie_posters_load_cleanly` |
| TC-50 | Zero manual selection controls in UI | Fresh DB | 1. Count `select`, `input`, `textarea`, `form` elements | All counts equal `0` | `test_50_zero_manual_selection_controls_in_ui` |
| TC-51 | Sole booking action button `BOOK MY TICKET` | Fresh DB | 1. Inspect `.hero-actions button` | Single visible, enabled `BOOK MY TICKET` button | `test_51_only_one_booking_action_button_book_my_ticket` |
| TC-52 | Navbar anchor links navigate cleanly | Fresh DB | 1. Click all 4 nav links | Target sections visible in viewport | `test_52_navbar_anchor_navigation_links_work` |
| TC-53 | History `View Ticket` loads digital pass | 2 bookings exist | 1. Click `View Ticket` on older booking | Digital ticket updates to older booking details | `test_53_booking_history_view_ticket_button_loads_ticket` |
| TC-54 | Live stats update dynamically without reload | Fresh DB | 1. Book ticket -> check stats -> cancel -> check stats | DOM counters update immediately | `test_54_live_stats_cards_update_after_book_and_cancel` |
| TC-55 | Auto-cancel when no bookings shows friendly error | Empty history | 1. Click `#auto-cancel-latest-btn` | Error banner shown gracefully | `test_55_auto_cancel_latest_when_empty_shows_error_banner` |
| TC-56 | Mobile viewport renders without horizontal overflow | Fresh DB | 1. Set viewport `375x812` 2. Check `scrollWidth - innerWidth` | Overflow `<= 2px` and CTA visible | `test_56_responsive_mobile_viewport_renders_without_horizontal_overflow` |

---

## 6. Testing Results Dashboard & Reports (TC-57 – TC-60)

| Test ID | Test Case Title | Preconditions | Test Steps | Expected Result | Automated Ref |
|---|---|---|---|---|---|
| TC-57 | Testing dashboard displays summary KPIs | App running | 1. Open `/` 2. Inspect `#testing-results-dashboard` | Total, Passed, Failed, Skipped, Pass %, Run All Tests, Download HTML, Download PDF visible | `test_57_testing_dashboard_displays_summary_metrics` |
| TC-58 | Dashboard lists all individual test cases | `test_results.json` present | 1. Open `/` 2. Count `#test-results-tbody tr` | `>= 50` individual rows rendered with ID, scenario, description, expected, actual, status, duration | `test_58_testing_dashboard_lists_all_individual_test_cases` |
| TC-59 | View individual test case details modal | Dashboard loaded | 1. Click `View Details` on a row 2. Click `Close` | Modal displays full test metadata and closes cleanly | `test_59_testing_dashboard_view_details_modal_opens` |
| TC-60 | Downloadable HTML and PDF reports valid | Reports generated | 1. GET `/api/tests/report/html` 2. GET `/api/tests/report/pdf` | Both return HTTP `200`; PDF starts with `%PDF-` | `test_60_downloadable_html_and_pdf_reports_return_valid_files` |
