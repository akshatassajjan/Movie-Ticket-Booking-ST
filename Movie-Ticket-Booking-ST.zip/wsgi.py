"""WSGI entrypoint for production deployments (Gunicorn / Waitress)."""
from app import create_app

app = create_app()
