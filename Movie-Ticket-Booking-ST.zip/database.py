"""SQLite database schema, seeding, and transactional auto-booking engine."""
from __future__ import annotations

import json
import os
import secrets
import sqlite3
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any

DEFAULT_DB_PATH = Path(__file__).resolve().parent / "cinema.db"
DEFAULT_SEAT_COUNT = 2
CONVENIENCE_FEE_PER_SEAT = 1.50
TAX_RATE = 0.18

MOVIES_SEED = [
    ("Starlight Odyssey", "Sci-Fi / Adventure", 148, "PG-13", 8.9, "English", "/static/posters/poster_01.svg", 14.00, "A deep-space crew charts a wormhole beyond Jupiter to rescue a lost research vessel."),
    ("Shadow Protocol", "Action / Thriller", 132, "R", 8.4, "English", "/static/posters/poster_02.svg", 13.50, "An intelligence analyst uncovers a rogue satellite network and has 24 hours to shut it down."),
    ("Velvet Monsoon", "Drama / Romance", 124, "PG-13", 8.2, "English", "/static/posters/poster_03.svg", 12.00, "Two architects reconnect across continents during one unforgettable rainy season."),
    ("Clockwork Heist", "Crime / Mystery", 128, "PG-13", 8.6, "English", "/static/posters/poster_04.svg", 13.00, "A master horologist engineers an impossible vault breach synchronized to Big Ben."),
    ("Neon Samurai", "Cyberpunk / Action", 139, "R", 8.8, "Japanese / English", "/static/posters/poster_05.svg", 14.50, "In rain-slicked Neo-Kansai, a retired blade guardian confronts a corporate AI syndicate."),
    ("Whispers of Pine", "Horror / Mystery", 112, "R", 7.9, "English", "/static/posters/poster_06.svg", 12.50, "A winter caretaker at a remote timber station hears radio transmissions from 1954."),
    ("Skyward Parcel", "Animation / Family", 104, "G", 8.5, "English", "/static/posters/poster_07.svg", 11.00, "A courier pigeon and a clockwork mouse cross storm clouds to deliver a birthday wish."),
    ("Grandmaster Gambit", "Biography / Drama", 136, "PG-13", 8.3, "English", "/static/posters/poster_08.svg", 12.50, "The true-inspired chronicle of an underdog prodigy rewriting championship chess."),
    ("Abyssal Drift", "Sci-Fi / Thriller", 121, "PG-13", 8.1, "English", "/static/posters/poster_09.svg", 13.50, "Submarine geologists discover a luminous cavern five miles beneath the Pacific floor."),
    ("Midnight Encore", "Musical / Drama", 118, "PG", 8.7, "English", "/static/posters/poster_10.svg", 12.00, "A jazz trumpeter rallies neighborhood musicians to save a historic downtown theater."),
    ("Desert Mirage", "Adventure / Western", 129, "PG-13", 8.0, "English", "/static/posters/poster_11.svg", 12.50, "Three outlaws race a sandstorm and a relentless marshal toward a sunken canyon fort."),
    ("Quantum Echo", "Sci-Fi / Mystery", 142, "PG-13", 9.0, "English", "/static/posters/poster_12.svg", 15.00, "A physicist receives encrypted voicemails from her own lab 48 hours in the future."),
]

THEATRES_SEED = [
    ("Grand Horizon IMAX", "Downtown Plaza", "IMAX Laser", 1.25),
    ("Lumiere Dolby Cinema", "Midtown Arts District", "Dolby Atmos", 1.15),
    ("Starplex Premiere", "Westside Mall", "4DX Motion", 1.20),
    ("Royal Crown Multiplex", "Harborfront Promenade", "Standard Premiere", 1.00),
]

SHOWTIME_SLOTS = ["10:30 AM", "02:15 PM", "06:00 PM", "09:30 PM"]
SEAT_ROWS = ["A", "B", "C", "D"]
SEATS_PER_ROW = 6


class BookingError(Exception):
    """Base error for booking domain failures."""

    def __init__(self, message: str, status_code: int = 400) -> None:
        super().__init__(message)
        self.message = message
        self.status_code = status_code


class NoAvailabilityError(BookingError):
    def __init__(self, message: str = "No available showtimes with enough seats.") -> None:
        super().__init__(message, status_code=409)


class DuplicateSeatError(BookingError):
    def __init__(self, message: str = "One or more requested seats are already booked.") -> None:
        super().__init__(message, status_code=409)


class BookingNotFoundError(BookingError):
    def __init__(self, message: str = "Booking ID not found.") -> None:
        super().__init__(message, status_code=404)


class BookingAlreadyCancelledError(BookingError):
    def __init__(self, message: str = "Booking is already cancelled.") -> None:
        super().__init__(message, status_code=409)


def get_connection(db_path: str | Path | None = None) -> sqlite3.Connection:
    path = str(db_path or os.environ.get("MOVIE_DB_PATH") or DEFAULT_DB_PATH)
    conn = sqlite3.connect(path, timeout=15.0, isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    conn.execute("PRAGMA journal_mode = WAL;")
    return conn


def init_db(db_path: str | Path | None = None, seed: bool = True) -> Path:
    path = Path(db_path or os.environ.get("MOVIE_DB_PATH") or DEFAULT_DB_PATH)
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = get_connection(path)
    try:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS movies (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL UNIQUE,
                genre TEXT NOT NULL,
                duration_mins INTEGER NOT NULL,
                rating TEXT NOT NULL,
                imdb_score REAL NOT NULL,
                language TEXT NOT NULL,
                poster_url TEXT NOT NULL,
                base_price REAL NOT NULL,
                synopsis TEXT NOT NULL,
                is_active INTEGER NOT NULL DEFAULT 1
            );

            CREATE TABLE IF NOT EXISTS theatres (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                location TEXT NOT NULL,
                screen_type TEXT NOT NULL,
                price_multiplier REAL NOT NULL DEFAULT 1.0,
                is_active INTEGER NOT NULL DEFAULT 1
            );

            CREATE TABLE IF NOT EXISTS showtimes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                movie_id INTEGER NOT NULL REFERENCES movies(id) ON DELETE CASCADE,
                theatre_id INTEGER NOT NULL REFERENCES theatres(id) ON DELETE CASCADE,
                show_date TEXT NOT NULL,
                show_time TEXT NOT NULL,
                total_seats INTEGER NOT NULL DEFAULT 24,
                is_active INTEGER NOT NULL DEFAULT 1,
                UNIQUE(movie_id, theatre_id, show_date, show_time)
            );

            CREATE TABLE IF NOT EXISTS seats (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                showtime_id INTEGER NOT NULL REFERENCES showtimes(id) ON DELETE CASCADE,
                seat_label TEXT NOT NULL,
                row_label TEXT NOT NULL,
                seat_number INTEGER NOT NULL,
                is_booked INTEGER NOT NULL DEFAULT 0,
                booking_id TEXT DEFAULT NULL,
                UNIQUE(showtime_id, seat_label)
            );

            CREATE TABLE IF NOT EXISTS bookings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                booking_id TEXT NOT NULL UNIQUE,
                movie_id INTEGER NOT NULL REFERENCES movies(id),
                theatre_id INTEGER NOT NULL REFERENCES theatres(id),
                showtime_id INTEGER NOT NULL REFERENCES showtimes(id),
                movie_title TEXT NOT NULL,
                theatre_name TEXT NOT NULL,
                theatre_location TEXT NOT NULL,
                screen_type TEXT NOT NULL,
                show_date TEXT NOT NULL,
                show_time TEXT NOT NULL,
                seat_count INTEGER NOT NULL,
                seats_json TEXT NOT NULL,
                unit_price REAL NOT NULL,
                ticket_price REAL NOT NULL,
                convenience_fee REAL NOT NULL,
                tax_amount REAL NOT NULL,
                total_amount REAL NOT NULL,
                payment_id TEXT NOT NULL UNIQUE,
                payment_method TEXT NOT NULL,
                payment_status TEXT NOT NULL,
                booking_status TEXT NOT NULL,
                created_at TEXT NOT NULL,
                cancelled_at TEXT DEFAULT NULL
            );

            CREATE TABLE IF NOT EXISTS booking_seats (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                showtime_id INTEGER NOT NULL REFERENCES showtimes(id) ON DELETE CASCADE,
                seat_label TEXT NOT NULL,
                booking_id TEXT NOT NULL REFERENCES bookings(booking_id) ON DELETE CASCADE,
                UNIQUE(showtime_id, seat_label)
            );
            """
        )
        if seed:
            seed_data(conn)
    finally:
        conn.close()
    return path


def seed_data(conn: sqlite3.Connection) -> None:
    existing_movies = conn.execute("SELECT COUNT(*) FROM movies").fetchone()[0]
    if existing_movies > 0:
        return

    conn.execute("BEGIN IMMEDIATE;")
    try:
        conn.executemany(
            """
            INSERT INTO movies (title, genre, duration_mins, rating, imdb_score, language, poster_url, base_price, synopsis)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            MOVIES_SEED,
        )
        conn.executemany(
            """
            INSERT INTO theatres (name, location, screen_type, price_multiplier)
            VALUES (?, ?, ?, ?)
            """,
            THEATRES_SEED,
        )

        movie_ids = [r[0] for r in conn.execute("SELECT id FROM movies ORDER BY id").fetchall()]
        theatre_ids = [r[0] for r in conn.execute("SELECT id FROM theatres ORDER BY id").fetchall()]
        today = date.today()
        dates = [(today + timedelta(days=offset)).isoformat() for offset in range(2)]

        showtime_rows = []
        for idx, m_id in enumerate(movie_ids):
            # Assign 2 theatres per movie in rotation so all 4 theatres are represented
            assigned_theatres = [
                theatre_ids[idx % len(theatre_ids)],
                theatre_ids[(idx + 1) % len(theatre_ids)],
            ]
            for t_id in assigned_theatres:
                for d_str in dates:
                    for slot in SHOWTIME_SLOTS[:2]:
                        showtime_rows.append((m_id, t_id, d_str, slot, len(SEAT_ROWS) * SEATS_PER_ROW))

        conn.executemany(
            """
            INSERT INTO showtimes (movie_id, theatre_id, show_date, show_time, total_seats)
            VALUES (?, ?, ?, ?, ?)
            """,
            showtime_rows,
        )

        showtime_ids = [r[0] for r in conn.execute("SELECT id FROM showtimes ORDER BY id").fetchall()]
        seat_rows = []
        for s_id in showtime_ids:
            for row_label in SEAT_ROWS:
                for num in range(1, SEATS_PER_ROW + 1):
                    seat_rows.append((s_id, f"{row_label}{num}", row_label, num, 0))

        conn.executemany(
            """
            INSERT INTO seats (showtime_id, seat_label, row_label, seat_number, is_booked)
            VALUES (?, ?, ?, ?, ?)
            """,
            seat_rows,
        )
        conn.execute("COMMIT;")
    except Exception:
        conn.execute("ROLLBACK;")
        raise


def calculate_pricing(base_price: float, price_multiplier: float, seat_count: int) -> dict[str, float]:
    unit_price = round(float(base_price) * float(price_multiplier), 2)
    ticket_price = round(unit_price * seat_count, 2)
    convenience_fee = round(CONVENIENCE_FEE_PER_SEAT * seat_count, 2)
    tax_amount = round((ticket_price + convenience_fee) * TAX_RATE, 2)
    total_amount = round(ticket_price + convenience_fee + tax_amount, 2)
    return {
        "unit_price": unit_price,
        "ticket_price": ticket_price,
        "convenience_fee": convenience_fee,
        "tax_amount": tax_amount,
        "total_amount": total_amount,
    }


def _pick_consecutive_or_first_seats(available_rows: list[sqlite3.Row], seat_count: int) -> list[sqlite3.Row]:
    by_row: dict[str, list[sqlite3.Row]] = {}
    for row in available_rows:
        by_row.setdefault(row["row_label"], []).append(row)

    for row_seats in by_row.values():
        if len(row_seats) < seat_count:
            continue
        for i in range(len(row_seats) - seat_count + 1):
            window = row_seats[i : i + seat_count]
            numbers = [s["seat_number"] for s in window]
            if numbers == list(range(numbers[0], numbers[0] + seat_count)):
                return window

    return available_rows[:seat_count]


def _serialize_booking(row: sqlite3.Row) -> dict[str, Any]:
    data = dict(row)
    data["seats"] = json.loads(data.pop("seats_json"))
    return data


def _generate_unique_code(conn: sqlite3.Connection, table: str, column: str, prefix: str) -> str:
    today_stamp = date.today().strftime("%Y%m%d")
    for _ in range(10):
        candidate = f"{prefix}-{today_stamp}-{secrets.token_hex(4).upper()}"
        exists = conn.execute(
            f"SELECT 1 FROM {table} WHERE {column} = ?", (candidate,)
        ).fetchone()
        if not exists:
            return candidate
    raise BookingError("Could not generate unique identifier.", status_code=500)


def perform_auto_booking(
    db_path: str | Path | None = None,
    seat_count: int | None = None,
) -> dict[str, Any]:
    """Run the full automatic booking workflow inside a single SQLite transaction."""
    if seat_count is None:
        required_seats = DEFAULT_SEAT_COUNT
    else:
        if isinstance(seat_count, bool) or not isinstance(seat_count, int):
            raise BookingError("seat_count must be an integer.", status_code=400)
        if seat_count < 1 or seat_count > 6:
            raise BookingError("seat_count must be between 1 and 6.", status_code=400)
        required_seats = seat_count

    today_str = date.today().isoformat()
    conn = get_connection(db_path)
    try:
        conn.execute("BEGIN IMMEDIATE;")

        # 1. Automatically choose an available movie (balanced across catalog + highest rating)
        movie_row = conn.execute(
            """
            SELECT m.*,
                   COALESCE((
                       SELECT COUNT(*) FROM bookings b
                       WHERE b.movie_id = m.id AND b.booking_status = 'CONFIRMED'
                   ), 0) AS confirmed_count
            FROM movies m
            WHERE m.is_active = 1
              AND EXISTS (
                  SELECT 1
                  FROM showtimes st
                  JOIN theatres t ON t.id = st.theatre_id
                  WHERE st.movie_id = m.id
                    AND st.is_active = 1
                    AND t.is_active = 1
                    AND st.show_date >= ?
                    AND (
                        SELECT COUNT(*) FROM seats s
                        WHERE s.showtime_id = st.id AND s.is_booked = 0
                    ) >= ?
              )
            ORDER BY confirmed_count ASC, m.imdb_score DESC, m.id ASC
            LIMIT 1
            """,
            (today_str, required_seats),
        ).fetchone()

        if not movie_row:
            raise NoAvailabilityError(
                f"No movies currently have a showtime with at least {required_seats} available seat(s)."
            )

        # 2. Automatically select an available theatre for the chosen movie
        theatre_row = conn.execute(
            """
            SELECT t.*,
                   MAX(avail.open_seats) AS max_open_seats
            FROM theatres t
            JOIN showtimes st ON st.theatre_id = t.id
            JOIN (
                SELECT showtime_id, COUNT(*) AS open_seats
                FROM seats
                WHERE is_booked = 0
                GROUP BY showtime_id
            ) avail ON avail.showtime_id = st.id
            WHERE st.movie_id = ?
              AND st.is_active = 1
              AND t.is_active = 1
              AND st.show_date >= ?
              AND avail.open_seats >= ?
            GROUP BY t.id
            ORDER BY max_open_seats DESC, t.id ASC
            LIMIT 1
            """,
            (movie_row["id"], today_str, required_seats),
        ).fetchone()

        if not theatre_row:
            raise NoAvailabilityError("No available theatre found for selected movie.")

        # 3. Automatically select the earliest available booking date
        date_row = conn.execute(
            """
            SELECT st.show_date
            FROM showtimes st
            WHERE st.movie_id = ?
              AND st.theatre_id = ?
              AND st.is_active = 1
              AND st.show_date >= ?
              AND (
                  SELECT COUNT(*) FROM seats s
                  WHERE s.showtime_id = st.id AND s.is_booked = 0
              ) >= ?
            ORDER BY st.show_date ASC
            LIMIT 1
            """,
            (movie_row["id"], theatre_row["id"], today_str, required_seats),
        ).fetchone()

        if not date_row:
            raise NoAvailabilityError("No available booking date found.")

        chosen_date = date_row["show_date"]

        # 4. Automatically select an available showtime on that date
        showtime_row = conn.execute(
            """
            SELECT st.*
            FROM showtimes st
            WHERE st.movie_id = ?
              AND st.theatre_id = ?
              AND st.show_date = ?
              AND st.is_active = 1
              AND (
                  SELECT COUNT(*) FROM seats s
                  WHERE s.showtime_id = st.id AND s.is_booked = 0
              ) >= ?
            ORDER BY st.id ASC
            LIMIT 1
            """,
            (movie_row["id"], theatre_row["id"], chosen_date, required_seats),
        ).fetchone()

        if not showtime_row:
            raise NoAvailabilityError("No available showtime found for selected date.")

        # 5. Automatically allocate available seats (prefer consecutive seats in same row)
        available_seats = conn.execute(
            """
            SELECT id, seat_label, row_label, seat_number
            FROM seats
            WHERE showtime_id = ? AND is_booked = 0
            ORDER BY row_label ASC, seat_number ASC
            """,
            (showtime_row["id"],),
        ).fetchall()

        if len(available_seats) < required_seats:
            raise NoAvailabilityError("Insufficient available seats in selected showtime.")

        chosen_seats = _pick_consecutive_or_first_seats(available_seats, required_seats)
        seat_labels = [s["seat_label"] for s in chosen_seats]

        # 6. Calculate ticket price, convenience fee, taxes, and total amount
        pricing = calculate_pricing(
            movie_row["base_price"], theatre_row["price_multiplier"], required_seats
        )

        # 7. Simulate automatic payment and generate unique IDs
        booking_id = _generate_unique_code(conn, "bookings", "booking_id", "CINE")
        payment_id = _generate_unique_code(conn, "bookings", "payment_id", "PAY")
        payment_method = "Auto-Pay Virtual Card •••• 4242"
        created_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # 8. Persist booking and lock seats atomically
        conn.execute(
            """
            INSERT INTO bookings (
                booking_id, movie_id, theatre_id, showtime_id,
                movie_title, theatre_name, theatre_location, screen_type,
                show_date, show_time, seat_count, seats_json,
                unit_price, ticket_price, convenience_fee, tax_amount, total_amount,
                payment_id, payment_method, payment_status, booking_status, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'PAID', 'CONFIRMED', ?)
            """,
            (
                booking_id,
                movie_row["id"],
                theatre_row["id"],
                showtime_row["id"],
                movie_row["title"],
                theatre_row["name"],
                theatre_row["location"],
                theatre_row["screen_type"],
                showtime_row["show_date"],
                showtime_row["show_time"],
                required_seats,
                json.dumps(seat_labels),
                pricing["unit_price"],
                pricing["ticket_price"],
                pricing["convenience_fee"],
                pricing["tax_amount"],
                pricing["total_amount"],
                payment_id,
                payment_method,
                created_at,
            ),
        )

        for label in seat_labels:
            try:
                conn.execute(
                    """
                    INSERT INTO booking_seats (showtime_id, seat_label, booking_id)
                    VALUES (?, ?, ?)
                    """,
                    (showtime_row["id"], label, booking_id),
                )
            except sqlite3.IntegrityError as exc:
                raise DuplicateSeatError(f"Seat {label} is already booked.") from exc

            cursor = conn.execute(
                """
                UPDATE seats
                SET is_booked = 1, booking_id = ?
                WHERE showtime_id = ? AND seat_label = ? AND is_booked = 0
                """,
                (booking_id, showtime_row["id"], label),
            )
            if cursor.rowcount != 1:
                raise DuplicateSeatError(f"Seat {label} could not be reserved.")

        conn.execute("COMMIT;")

        saved = conn.execute(
            "SELECT * FROM bookings WHERE booking_id = ?", (booking_id,)
        ).fetchone()
        booking_data = _serialize_booking(saved)
        booking_data["poster_url"] = movie_row["poster_url"]
        booking_data["genre"] = movie_row["genre"]
        booking_data["rating"] = movie_row["rating"]
        booking_data["duration_mins"] = movie_row["duration_mins"]

        workflow_steps = [
            {"step": 1, "key": "movie", "label": "Auto-Selected Movie", "value": movie_row["title"]},
            {"step": 2, "key": "theatre", "label": "Auto-Selected Theatre", "value": f"{theatre_row['name']} ({theatre_row['screen_type']})"},
            {"step": 3, "key": "date", "label": "Auto-Selected Date", "value": showtime_row["show_date"]},
            {"step": 4, "key": "showtime", "label": "Auto-Selected Showtime", "value": showtime_row["show_time"]},
            {"step": 5, "key": "seats", "label": "Auto-Allocated Seats", "value": ", ".join(seat_labels)},
            {"step": 6, "key": "pricing", "label": "Calculated Total", "value": f"${pricing['total_amount']:.2f}"},
            {"step": 7, "key": "payment", "label": "Auto-Pay Completed", "value": payment_id},
            {"step": 8, "key": "ticket", "label": "Digital Ticket Issued", "value": booking_id},
        ]

        return {"booking": booking_data, "workflow_steps": workflow_steps}
    except Exception:
        if conn.in_transaction:
            conn.execute("ROLLBACK;")
        raise
    finally:
        conn.close()


def reserve_specific_seats(
    showtime_id: int,
    seat_labels: list[str],
    db_path: str | Path | None = None,
) -> dict[str, Any]:
    """Transactional helper for verifying duplicate-seat prevention against a specific showtime."""
    if not seat_labels:
        raise BookingError("At least one seat label is required.", status_code=400)

    conn = get_connection(db_path)
    try:
        conn.execute("BEGIN IMMEDIATE;")
        show_row = conn.execute(
            """
            SELECT st.*, m.title AS movie_title, m.base_price,
                   t.name AS theatre_name, t.location AS theatre_location,
                   t.screen_type, t.price_multiplier
            FROM showtimes st
            JOIN movies m ON m.id = st.movie_id
            JOIN theatres t ON t.id = st.theatre_id
            WHERE st.id = ? AND st.is_active = 1
            """,
            (showtime_id,),
        ).fetchone()
        if not show_row:
            raise BookingError("Showtime not found or inactive.", status_code=404)

        for label in seat_labels:
            seat_row = conn.execute(
                "SELECT is_booked FROM seats WHERE showtime_id = ? AND seat_label = ?",
                (showtime_id, label),
            ).fetchone()
            if not seat_row:
                raise BookingError(f"Seat {label} does not exist for showtime {showtime_id}.", status_code=400)
            if seat_row["is_booked"] == 1:
                raise DuplicateSeatError(f"Seat {label} is already booked for this showtime.")

        pricing = calculate_pricing(
            show_row["base_price"], show_row["price_multiplier"], len(seat_labels)
        )
        booking_id = _generate_unique_code(conn, "bookings", "booking_id", "CINE")
        payment_id = _generate_unique_code(conn, "bookings", "payment_id", "PAY")
        created_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        conn.execute(
            """
            INSERT INTO bookings (
                booking_id, movie_id, theatre_id, showtime_id,
                movie_title, theatre_name, theatre_location, screen_type,
                show_date, show_time, seat_count, seats_json,
                unit_price, ticket_price, convenience_fee, tax_amount, total_amount,
                payment_id, payment_method, payment_status, booking_status, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Auto-Pay Virtual Card •••• 4242', 'PAID', 'CONFIRMED', ?)
            """,
            (
                booking_id,
                show_row["movie_id"],
                show_row["theatre_id"],
                showtime_id,
                show_row["movie_title"],
                show_row["theatre_name"],
                show_row["theatre_location"],
                show_row["screen_type"],
                show_row["show_date"],
                show_row["show_time"],
                len(seat_labels),
                json.dumps(seat_labels),
                pricing["unit_price"],
                pricing["ticket_price"],
                pricing["convenience_fee"],
                pricing["tax_amount"],
                pricing["total_amount"],
                payment_id,
                created_at,
            ),
        )

        for label in seat_labels:
            try:
                conn.execute(
                    "INSERT INTO booking_seats (showtime_id, seat_label, booking_id) VALUES (?, ?, ?)",
                    (showtime_id, label, booking_id),
                )
            except sqlite3.IntegrityError as exc:
                raise DuplicateSeatError(f"Seat {label} is already booked.") from exc

            cursor = conn.execute(
                "UPDATE seats SET is_booked = 1, booking_id = ? WHERE showtime_id = ? AND seat_label = ? AND is_booked = 0",
                (booking_id, showtime_id, label),
            )
            if cursor.rowcount != 1:
                raise DuplicateSeatError(f"Seat {label} is already booked.")

        conn.execute("COMMIT;")
        saved = conn.execute("SELECT * FROM bookings WHERE booking_id = ?", (booking_id,)).fetchone()
        return _serialize_booking(saved)
    except Exception:
        if conn.in_transaction:
            conn.execute("ROLLBACK;")
        raise
    finally:
        conn.close()


def cancel_booking(booking_id: str, db_path: str | Path | None = None) -> dict[str, Any]:
    if not booking_id or not booking_id.strip():
        raise BookingError("Invalid booking ID.", status_code=400)

    conn = get_connection(db_path)
    try:
        conn.execute("BEGIN IMMEDIATE;")
        row = conn.execute(
            "SELECT * FROM bookings WHERE booking_id = ?", (booking_id.strip(),)
        ).fetchone()
        if not row:
            raise BookingNotFoundError(f"Booking '{booking_id}' does not exist.")
        if row["booking_status"] == "CANCELLED":
            raise BookingAlreadyCancelledError(f"Booking '{booking_id}' is already cancelled.")

        cancelled_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        conn.execute(
            """
            UPDATE bookings
            SET booking_status = 'CANCELLED',
                payment_status = 'REFUNDED',
                cancelled_at = ?
            WHERE booking_id = ?
            """,
            (cancelled_at, booking_id.strip()),
        )
        conn.execute("DELETE FROM booking_seats WHERE booking_id = ?", (booking_id.strip(),))
        conn.execute(
            "UPDATE seats SET is_booked = 0, booking_id = NULL WHERE booking_id = ?",
            (booking_id.strip(),),
        )
        conn.execute("COMMIT;")

        updated = conn.execute(
            """
            SELECT b.*, m.poster_url, m.genre, m.rating, m.duration_mins
            FROM bookings b
            JOIN movies m ON m.id = b.movie_id
            WHERE b.booking_id = ?
            """,
            (booking_id.strip(),),
        ).fetchone()
        return _serialize_booking(updated)
    except Exception:
        if conn.in_transaction:
            conn.execute("ROLLBACK;")
        raise
    finally:
        conn.close()


def cancel_latest_booking(db_path: str | Path | None = None) -> dict[str, Any]:
    conn = get_connection(db_path)
    try:
        row = conn.execute(
            """
            SELECT booking_id FROM bookings
            WHERE booking_status = 'CONFIRMED'
            ORDER BY id DESC
            LIMIT 1
            """
        ).fetchone()
    finally:
        conn.close()

    if not row:
        raise BookingNotFoundError("No confirmed bookings available to cancel.")
    return cancel_booking(row["booking_id"], db_path=db_path)


def list_movies(db_path: str | Path | None = None) -> list[dict[str, Any]]:
    today_str = date.today().isoformat()
    conn = get_connection(db_path)
    try:
        rows = conn.execute(
            """
            SELECT m.*,
                   COUNT(DISTINCT st.id) AS showtime_count,
                   COALESCE(SUM(CASE WHEN s.is_booked = 0 THEN 1 ELSE 0 END), 0) AS available_seats
            FROM movies m
            LEFT JOIN showtimes st ON st.movie_id = m.id AND st.is_active = 1 AND st.show_date >= ?
            LEFT JOIN seats s ON s.showtime_id = st.id
            WHERE m.is_active = 1
            GROUP BY m.id
            ORDER BY m.id ASC
            """,
            (today_str,),
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def list_bookings(db_path: str | Path | None = None) -> list[dict[str, Any]]:
    conn = get_connection(db_path)
    try:
        rows = conn.execute(
            """
            SELECT b.*, m.poster_url, m.genre, m.rating, m.duration_mins
            FROM bookings b
            JOIN movies m ON m.id = b.movie_id
            ORDER BY b.id DESC
            """
        ).fetchall()
        return [_serialize_booking(r) for r in rows]
    finally:
        conn.close()


def get_booking(booking_id: str, db_path: str | Path | None = None) -> dict[str, Any]:
    conn = get_connection(db_path)
    try:
        row = conn.execute(
            """
            SELECT b.*, m.poster_url, m.genre, m.rating, m.duration_mins
            FROM bookings b
            JOIN movies m ON m.id = b.movie_id
            WHERE b.booking_id = ?
            """,
            (booking_id,),
        ).fetchone()
        if not row:
            raise BookingNotFoundError(f"Booking '{booking_id}' not found.")
        return _serialize_booking(row)
    finally:
        conn.close()


def get_system_status(db_path: str | Path | None = None) -> dict[str, Any]:
    today_str = date.today().isoformat()
    conn = get_connection(db_path)
    try:
        movies_count = conn.execute("SELECT COUNT(*) FROM movies WHERE is_active = 1").fetchone()[0]
        theatres_count = conn.execute("SELECT COUNT(*) FROM theatres WHERE is_active = 1").fetchone()[0]
        showtimes_count = conn.execute(
            "SELECT COUNT(*) FROM showtimes WHERE is_active = 1 AND show_date >= ?", (today_str,)
        ).fetchone()[0]
        available_seats = conn.execute(
            """
            SELECT COUNT(*) FROM seats s
            JOIN showtimes st ON st.id = s.showtime_id
            WHERE s.is_booked = 0 AND st.is_active = 1 AND st.show_date >= ?
            """,
            (today_str,),
        ).fetchone()[0]
        confirmed_bookings = conn.execute(
            "SELECT COUNT(*) FROM bookings WHERE booking_status = 'CONFIRMED'"
        ).fetchone()[0]
        cancelled_bookings = conn.execute(
            "SELECT COUNT(*) FROM bookings WHERE booking_status = 'CANCELLED'"
        ).fetchone()[0]
        return {
            "movies_count": movies_count,
            "theatres_count": theatres_count,
            "showtimes_count": showtimes_count,
            "available_seats": available_seats,
            "confirmed_bookings": confirmed_bookings,
            "cancelled_bookings": cancelled_bookings,
        }
    finally:
        conn.close()
