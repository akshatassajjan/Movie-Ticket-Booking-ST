# CineAuto — Automatic One-Click Movie Ticket Booking System

A complete **Software Testing Mini Project** built with **Python, Flask, HTML, CSS, JavaScript, SQLite, and Playwright**.

## Key Features
- **100% Automatic One-Click Booking**: No movie dropdowns, no theatre selectors, no date pickers, no showtime menus, and no manual seat selection. Clicking **`BOOK MY TICKET`** runs the full booking pipeline automatically.
- **12 Seeded Movies with Custom SVG Posters**: Offline-ready, vibrant vector posters stored in `static/posters/`.
- **Autonomous Allocation Engine**:
  1. Automatically chooses an available movie (balanced across catalog + highest rating).
  2. Automatically selects an available partner theatre.
  3. Automatically selects the earliest available booking date.
  4. Automatically selects an available showtime.
  5. Automatically allocates adjacent available seats (or next available seats) while preventing duplicate seat bookings via SQLite `BEGIN IMMEDIATE` transactions and `UNIQUE(showtime_id, seat_label)` constraints.
  6. Automatically calculates ticket subtotal, convenience fee (`$1.50/seat`), 18% GST tax, and grand total.
  7. Automatically completes simulated payment (`PAY-YYYYMMDD-XXXXXXXX`).
  8. Automatically generates a unique booking ID (`CINE-YYYYMMDD-XXXXXXXX`) and renders an interactive digital ticket with SVG barcode.
- **Booking History & Automatic Cancellation**: View past tickets and cancel bookings in one click to immediately refund payment and release seats back to inventory.
- **56 Playwright Automated Tests**: Full E2E UI, API, concurrency/duplicate-prevention, cancellation, and SQLite integrity test suite with HTML test reporting and automatic failure screenshots.

## Project Structure
```text
movie ticket booking/
├── app.py                        # Flask web server & REST API
├── database.py                   # SQLite schema, seeding & transactional auto-booking engine
├── requirements.txt              # Python dependencies
├── pytest.ini                    # Pytest + HTML report configuration
├── templates/index.html          # Zero-manual-selection single-page UI
├── static/
│   ├── css/style.css             # Dark cinema UI + pipeline animations + ticket styles
│   ├── js/app.js                 # Automatic booking workflow & live state sync
│   └── posters/poster_01..12.svg # 12 custom movie posters
├── tests/
│   ├── conftest.py               # Live server, isolated temp DB, Playwright & failure screenshot hook
│   ├── test_auto_selection.py
│   ├── test_pricing_payment_ticket.py
│   ├── test_duplicates_cancellation.py
│   ├── test_database_integrity.py
│   └── test_ui_navigation.py
├── docs/
│   ├── MANUAL_TEST_CASES.md      # 56 manual test cases
│   └── TEST_EXECUTION_SUMMARY.md # Test execution summary
├── reports/
│   ├── test_report.html          # Self-contained HTML test report
│   └── screenshots/              # Failure screenshots (auto-captured on any test failure)
└── scripts/
    ├── generate_posters.py       # Regenerates SVG posters
    └── package_project.py        # Packages project into ZIP archive
```

## Quick Start
1. Install dependencies:
   ```powershell
   py -m pip install -r requirements.txt
   ```
2. Run the Flask web application:
   ```powershell
   py app.py
   ```
   Open `http://127.0.0.1:5000` in your browser and click **BOOK MY TICKET**.
3. Run the 56 Playwright automated tests and generate the HTML report:
   ```powershell
   py -m pytest
   ```
   The HTML report is saved at `reports/test_report.html`. If any test fails, a full-page screenshot is automatically saved to `reports/screenshots/` and embedded in the HTML report.
