"""Playwright tests for duplicate seat prevention, cancellation, and invalid/unavailable scenarios."""
from __future__ import annotations

from playwright.sync_api import APIRequestContext, Page, expect

from database import get_connection


def _book_via_ui(page: Page, base_url: str) -> str:
    page.goto(base_url, wait_until="networkidle")
    page.click("#book-my-ticket-btn")
    expect(page.locator("#digital-ticket-card")).to_be_visible(timeout=10000)
    expect(page.locator("#pipeline-state-label")).to_contain_text("Completed", timeout=10000)
    return page.locator("#ticket-booking-id").inner_text().strip()


def test_27_duplicate_seat_booking_prevented_via_api(api_context: APIRequestContext) -> None:
    r1 = api_context.post(
        "/api/bookings/reserve-seats",
        data={"showtime_id": 1, "seat_labels": ["A1", "A2"]},
    )
    assert r1.status == 201

    r2 = api_context.post(
        "/api/bookings/reserve-seats",
        data={"showtime_id": 1, "seat_labels": ["A1"]},
    )
    assert r2.status == 409
    assert "already booked" in r2.json()["error"].lower()


def test_28_partial_seat_overlap_prevented(
    api_context: APIRequestContext, isolated_db
) -> None:
    r1 = api_context.post(
        "/api/bookings/reserve-seats",
        data={"showtime_id": 1, "seat_labels": ["B1", "B2"]},
    )
    assert r1.status == 201

    r2 = api_context.post(
        "/api/bookings/reserve-seats",
        data={"showtime_id": 1, "seat_labels": ["B2", "B3"]},
    )
    assert r2.status == 409

    # Ensure atomic rollback did not mark B3 as booked
    conn = get_connection(isolated_db)
    try:
        b3 = conn.execute(
            "SELECT is_booked FROM seats WHERE showtime_id = 1 AND seat_label = 'B3'"
        ).fetchone()
        assert b3["is_booked"] == 0
    finally:
        conn.close()


def test_29_sequential_auto_bookings_never_assign_duplicate_seats(
    api_context: APIRequestContext,
) -> None:
    allocated = set()
    for _ in range(12):
        res = api_context.post("/api/auto-book", data={})
        assert res.status == 201
        b = res.json()["booking"]
        for seat in b["seats"]:
            pair = (b["showtime_id"], seat)
            assert pair not in allocated, f"Duplicate allocation detected: {pair}"
            allocated.add(pair)


def test_30_cancel_booking_from_digital_ticket_button(page: Page, base_url: str) -> None:
    booking_id = _book_via_ui(page, base_url)
    page.click("#ticket-cancel-btn")
    expect(page.locator("#ticket-status-badge")).to_have_text("CANCELLED")
    expect(page.locator("#ticket-payment-status")).to_have_text("REFUNDED")
    expect(page.locator("#ticket-cancel-btn")).to_be_disabled()
    expect(page.locator("#status-banner")).to_contain_text(booking_id)


def test_31_cancel_booking_from_history_row_button(page: Page, base_url: str) -> None:
    booking_id = _book_via_ui(page, base_url)
    row = page.locator(f".history-item[data-booking-id='{booking_id}']")
    row.locator(".btn-cancel-booking").click()
    expect(row.locator(".status-chip")).to_have_text("CANCELLED")
    assert row.locator(".btn-cancel-booking").count() == 0


def test_32_auto_cancel_latest_button_cancels_newest_confirmed(
    page: Page, base_url: str, api_context: APIRequestContext
) -> None:
    b1 = api_context.post("/api/auto-book", data={}).json()["booking"]["booking_id"]
    b2 = api_context.post("/api/auto-book", data={}).json()["booking"]["booking_id"]

    page.goto(base_url, wait_until="networkidle")
    page.click("#auto-cancel-latest-btn")

    expect(page.locator(f".history-item[data-booking-id='{b2}'] .status-chip")).to_have_text("CANCELLED")
    expect(page.locator(f".history-item[data-booking-id='{b1}'] .status-chip")).to_have_text("CONFIRMED")


def test_33_cancellation_releases_seats_for_rebooking(
    api_context: APIRequestContext, isolated_db
) -> None:
    r1 = api_context.post(
        "/api/bookings/reserve-seats",
        data={"showtime_id": 1, "seat_labels": ["A1", "A2"]},
    )
    assert r1.status == 201
    booking_id = r1.json()["booking"]["booking_id"]

    cancel_res = api_context.post(f"/api/bookings/{booking_id}/cancel")
    assert cancel_res.status == 200

    # Now A1, A2 must be available to book again
    r2 = api_context.post(
        "/api/bookings/reserve-seats",
        data={"showtime_id": 1, "seat_labels": ["A1", "A2"]},
    )
    assert r2.status == 201


def test_34_double_cancellation_returns_409_error(api_context: APIRequestContext) -> None:
    b_id = api_context.post("/api/auto-book", data={}).json()["booking"]["booking_id"]
    first_cancel = api_context.post(f"/api/bookings/{b_id}/cancel")
    assert first_cancel.status == 200

    second_cancel = api_context.post(f"/api/bookings/{b_id}/cancel")
    assert second_cancel.status == 409
    assert "already cancelled" in second_cancel.json()["error"].lower()


def test_35_cancel_nonexistent_booking_returns_404(api_context: APIRequestContext) -> None:
    res = api_context.post("/api/bookings/CINE-NONEXISTENT-9999/cancel")
    assert res.status == 404


def test_36_get_nonexistent_booking_returns_404(api_context: APIRequestContext) -> None:
    res = api_context.get("/api/bookings/DOES-NOT-EXIST")
    assert res.status == 404


def test_37_invalid_seat_count_values_rejected(api_context: APIRequestContext) -> None:
    for invalid in (0, -2, 7, "two", True):
        res = api_context.post("/api/auto-book", data={"seat_count": invalid})
        assert res.status == 400


def test_38_sold_out_all_showtimes_shows_error_banner_in_ui(
    page: Page, base_url: str, isolated_db
) -> None:
    conn = get_connection(isolated_db)
    try:
        conn.execute("UPDATE seats SET is_booked = 1")
    finally:
        conn.close()

    page.goto(base_url, wait_until="networkidle")
    page.click("#book-my-ticket-btn")
    banner = page.locator("#status-banner")
    expect(banner).to_be_visible(timeout=10000)
    assert "error" in (banner.get_attribute("class") or "")
    assert "no movies" in banner.inner_text().lower()
