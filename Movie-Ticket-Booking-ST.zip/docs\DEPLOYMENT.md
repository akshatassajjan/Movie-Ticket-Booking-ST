# Deployment Guide — CineAuto Movie Ticket Booking System

This project includes production deployment configurations for **Render**, **Railway**, **Docker**, and **Windows/Linux WSGI servers**.

---

## Option 1: Deploy to Render (Recommended — Free Tier)
1. Push this project folder to a GitHub repository (`git init && git add . && git commit -m "Initial deploy"`).
2. Go to [render.com](https://render.com) -> **New +** -> **Blueprint** (or **Web Service**).
3. Connect your GitHub repository. Render automatically detects [`render.yaml`](../render.yaml):
   - **Build Command:** `pip install -r requirements.txt && python -m playwright install chromium`
   - **Start Command:** `gunicorn wsgi:app --bind 0.0.0.0:$PORT --workers 1 --threads 4 --timeout 300`
   - **Health Check:** `/health`
4. Click **Apply / Deploy Web Service**. Once live, open your `https://<app-name>.onrender.com` URL.

*(Note: Using `--workers 1 --threads 4` ensures SQLite write transactions remain lock-safe without multi-process write contention.)*

---

## Option 2: Deploy to Railway
1. Push this project to GitHub.
2. Go to [railway.app](https://railway.app) -> **New Project** -> **Deploy from GitHub repo**.
3. Railway automatically reads [`Procfile`](../Procfile) and [`requirements.txt`](../requirements.txt).
4. Optional environment variables:
   - `MOVIE_DB_PATH=/data/cinema.db` (if you attach a persistent volume at `/data`).
5. Generate a public domain in Railway **Settings -> Networking**.

---

## Option 3: Deploy with Docker (Any Cloud / VPS / Fly.io / Cloud Run)
Build and run locally or on any container host:
```bash
docker build -t cineauto-booking .
docker run -d -p 5000:5000 --name cineauto cineauto-booking
```
Then open `http://localhost:5000` (or your server IP/domain).

---

## Option 4: Run in Production on Windows (Waitress)
```powershell
py -m waitress --host=0.0.0.0 --port=5000 wsgi:app
```
