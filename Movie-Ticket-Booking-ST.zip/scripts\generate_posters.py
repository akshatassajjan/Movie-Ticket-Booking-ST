"""Generate 12 distinct, high-craft SVG movie posters in static/posters/."""
from pathlib import Path

POSTERS = [
    {
        "filename": "poster_01.svg",
        "title": "STARLIGHT ODYSSEY",
        "subtitle": "BEYOND THE EVENT HORIZON",
        "genre": "SCI-FI • ADVENTURE",
        "rating": "PG-13",
        "score": "8.9",
        "bg1": "#0b1026",
        "bg2": "#1d2b64",
        "accent": "#38bdf8",
        "accent2": "#f472b6",
        "motif": "planet",
    },
    {
        "filename": "poster_02.svg",
        "title": "SHADOW PROTOCOL",
        "subtitle": "TRUST NO SIGNAL",
        "genre": "ACTION • THRILLER",
        "rating": "R",
        "score": "8.4",
        "bg1": "#111111",
        "bg2": "#3b0a0a",
        "accent": "#ef4444",
        "accent2": "#f59e0b",
        "motif": "crosshair",
    },
    {
        "filename": "poster_03.svg",
        "title": "VELVET MONSOON",
        "subtitle": "SOME PROMISES OUTLAST TIME",
        "genre": "DRAMA • ROMANCE",
        "rating": "PG-13",
        "score": "8.2",
        "bg1": "#1f1135",
        "bg2": "#5b216b",
        "accent": "#fb7185",
        "accent2": "#fde047",
        "motif": "moon",
    },
    {
        "filename": "poster_04.svg",
        "title": "CLOCKWORK HEIST",
        "subtitle": "SIXTY SECONDS TO ZERO",
        "genre": "CRIME • MYSTERY",
        "rating": "PG-13",
        "score": "8.6",
        "bg1": "#0f172a",
        "bg2": "#1e3a3a",
        "accent": "#facc15",
        "accent2": "#2dd4bf",
        "motif": "gears",
    },
    {
        "filename": "poster_05.svg",
        "title": "NEON SAMURAI",
        "subtitle": "STEEL IN THE RAIN",
        "genre": "CYBERPUNK • ACTION",
        "rating": "R",
        "score": "8.8",
        "bg1": "#090418",
        "bg2": "#311042",
        "accent": "#e879f9",
        "accent2": "#22d3ee",
        "motif": "katana",
    },
    {
        "filename": "poster_06.svg",
        "title": "WHISPERS OF PINE",
        "subtitle": "THE FOREST REMEMBERS",
        "genre": "HORROR • MYSTERY",
        "rating": "R",
        "score": "7.9",
        "bg1": "#07140e",
        "bg2": "#123524",
        "accent": "#4ade80",
        "accent2": "#a3e635",
        "motif": "trees",
    },
    {
        "filename": "poster_07.svg",
        "title": "SKYWARD PARCEL",
        "subtitle": "A BIG DREAM IN A SMALL BOX",
        "genre": "ANIMATION • FAMILY",
        "rating": "G",
        "score": "8.5",
        "bg1": "#0c2d48",
        "bg2": "#145da0",
        "accent": "#fbbf24",
        "accent2": "#7dd3fc",
        "motif": "balloon",
    },
    {
        "filename": "poster_08.svg",
        "title": "GRANDMASTER GAMBIT",
        "subtitle": "EVERY MOVE HAS A PRICE",
        "genre": "BIOGRAPHY • DRAMA",
        "rating": "PG-13",
        "score": "8.3",
        "bg1": "#1c1917",
        "bg2": "#44403c",
        "accent": "#fb923c",
        "accent2": "#fef08a",
        "motif": "crown",
    },
    {
        "filename": "poster_09.svg",
        "title": "ABYSSAL DRIFT",
        "subtitle": "FIVE MILES BELOW LIGHT",
        "genre": "SCI-FI • THRILLER",
        "rating": "PG-13",
        "score": "8.1",
        "bg1": "#020617",
        "bg2": "#0c4a6e",
        "accent": "#06b6d4",
        "accent2": "#818cf8",
        "motif": "waves",
    },
    {
        "filename": "poster_10.svg",
        "title": "MIDNIGHT ENCORE",
        "subtitle": "ONE LAST SONG FOR THE CITY",
        "genre": "MUSICAL • DRAMA",
        "rating": "PG",
        "score": "8.7",
        "bg1": "#1a0b2e",
        "bg2": "#4a154b",
        "accent": "#f43f5e",
        "accent2": "#fcd34d",
        "motif": "spotlight",
    },
    {
        "filename": "poster_11.svg",
        "title": "DESERT MIRAGE",
        "subtitle": "GOLD BURIES THE GREEDY",
        "genre": "ADVENTURE • WESTERN",
        "rating": "PG-13",
        "score": "8.0",
        "bg1": "#291405",
        "bg2": "#7c2d12",
        "accent": "#f59e0b",
        "accent2": "#fdba74",
        "motif": "sun",
    },
    {
        "filename": "poster_12.svg",
        "title": "QUANTUM ECHO",
        "subtitle": "YESTERDAY HASN'T HAPPENED YET",
        "genre": "SCI-FI • MYSTERY",
        "rating": "PG-13",
        "score": "9.0",
        "bg1": "#06121e",
        "bg2": "#162447",
        "accent": "#34d399",
        "accent2": "#60a5fa",
        "motif": "atom",
    },
]


def _motif_svg(motif: str, accent: str, accent2: str) -> str:
    if motif == "planet":
        return f"""
        <circle cx="180" cy="200" r="72" fill="url(#glow)" opacity="0.9"/>
        <ellipse cx="180" cy="200" rx="125" ry="28" fill="none" stroke="{accent2}" stroke-width="4" transform="rotate(-18 180 200)" opacity="0.85"/>
        <circle cx="70" cy="95" r="3" fill="#fff" opacity="0.9"/>
        <circle cx="290" cy="120" r="2.5" fill="{accent}" opacity="0.9"/>
        <circle cx="260" cy="295" r="2" fill="#fff" opacity="0.8"/>
        <circle cx="95" cy="285" r="3.5" fill="{accent2}" opacity="0.7"/>
        """
    if motif == "crosshair":
        return f"""
        <circle cx="180" cy="200" r="85" fill="none" stroke="{accent}" stroke-width="3" opacity="0.75"/>
        <circle cx="180" cy="200" r="52" fill="none" stroke="{accent2}" stroke-width="2" stroke-dasharray="8 6"/>
        <line x1="70" y1="200" x2="290" y2="200" stroke="{accent}" stroke-width="2" opacity="0.7"/>
        <line x1="180" y1="90" x2="180" y2="310" stroke="{accent}" stroke-width="2" opacity="0.7"/>
        <circle cx="180" cy="200" r="12" fill="{accent}"/>
        """
    if motif == "moon":
        return f"""
        <circle cx="180" cy="190" r="76" fill="{accent}" opacity="0.22"/>
        <circle cx="180" cy="190" r="56" fill="{accent2}" opacity="0.85"/>
        <circle cx="205" cy="175" r="50" fill="#2d1441"/>
        <path d="M50 285 Q180 245 310 285" fill="none" stroke="{accent}" stroke-width="3" opacity="0.7"/>
        """
    if motif == "gears":
        return f"""
        <circle cx="155" cy="190" r="58" fill="none" stroke="{accent}" stroke-width="10" stroke-dasharray="16 10"/>
        <circle cx="155" cy="190" r="24" fill="none" stroke="{accent2}" stroke-width="4"/>
        <circle cx="228" cy="238" r="38" fill="none" stroke="{accent2}" stroke-width="8" stroke-dasharray="12 8"/>
        <circle cx="228" cy="238" r="14" fill="{accent}"/>
        """
    if motif == "katana":
        return f"""
        <polygon points="85,295 275,95 288,108 102,302" fill="url(#glow)" opacity="0.95"/>
        <line x1="75" y1="265" x2="120" y2="310" stroke="{accent2}" stroke-width="8" stroke-linecap="round"/>
        <circle cx="180" cy="195" r="88" fill="none" stroke="{accent}" stroke-width="2" opacity="0.45"/>
        """
    if motif == "trees":
        return f"""
        <polygon points="180,105 120,245 240,245" fill="{accent}" opacity="0.28"/>
        <polygon points="125,145 75,275 175,275" fill="{accent2}" opacity="0.22"/>
        <polygon points="235,145 185,275 285,275" fill="{accent}" opacity="0.22"/>
        <circle cx="180" cy="115" r="26" fill="{accent2}" opacity="0.6"/>
        """
    if motif == "balloon":
        return f"""
        <circle cx="180" cy="175" r="68" fill="url(#glow)"/>
        <path d="M148 118 Q180 175 148 232" fill="none" stroke="#ffffff" stroke-width="2" opacity="0.45"/>
        <path d="M212 118 Q180 175 212 232" fill="none" stroke="#ffffff" stroke-width="2" opacity="0.45"/>
        <rect x="164" y="262" width="32" height="24" rx="4" fill="{accent2}"/>
        <line x1="164" y1="240" x2="168" y2="262" stroke="#fff" stroke-width="2"/>
        <line x1="196" y1="240" x2="192" y2="262" stroke="#fff" stroke-width="2"/>
        """
    if motif == "crown":
        return f"""
        <polygon points="95,245 110,145 150,195 180,125 210,195 250,145 265,245" fill="url(#glow)" opacity="0.9"/>
        <rect x="95" y="252" width="170" height="16" rx="4" fill="{accent2}"/>
        """
    if motif == "waves":
        return f"""
        <circle cx="180" cy="175" r="64" fill="none" stroke="{accent}" stroke-width="3" opacity="0.7"/>
        <path d="M50 225 Q115 195 180 225 T310 225" fill="none" stroke="{accent}" stroke-width="5"/>
        <path d="M50 252 Q115 222 180 252 T310 252" fill="none" stroke="{accent2}" stroke-width="4" opacity="0.8"/>
        <path d="M50 278 Q115 248 180 278 T310 278" fill="none" stroke="{accent}" stroke-width="3" opacity="0.5"/>
        """
    if motif == "spotlight":
        return f"""
        <polygon points="180,75 85,295 275,295" fill="url(#glow)" opacity="0.35"/>
        <circle cx="180" cy="215" r="46" fill="none" stroke="{accent2}" stroke-width="4"/>
        <circle cx="180" cy="215" r="16" fill="{accent}"/>
        """
    if motif == "sun":
        return f"""
        <circle cx="180" cy="185" r="68" fill="url(#glow)"/>
        <polygon points="40,285 135,205 220,285" fill="#1c0d04" opacity="0.85"/>
        <polygon points="150,285 245,195 320,285" fill="#2d1305" opacity="0.9"/>
        """
    # atom
    return f"""
    <ellipse cx="180" cy="195" rx="95" ry="34" fill="none" stroke="{accent}" stroke-width="3" transform="rotate(30 180 195)"/>
    <ellipse cx="180" cy="195" rx="95" ry="34" fill="none" stroke="{accent2}" stroke-width="3" transform="rotate(-30 180 195)"/>
    <ellipse cx="180" cy="195" rx="95" ry="34" fill="none" stroke="{accent}" stroke-width="3" transform="rotate(90 180 195)"/>
    <circle cx="180" cy="195" r="14" fill="{accent2}"/>
    """


def generate_all(output_dir: Path) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    for item in POSTERS:
        motif_markup = _motif_svg(item["motif"], item["accent"], item["accent2"])
        title_words = item["title"].split(" ", 1)
        line1 = title_words[0]
        line2 = title_words[1] if len(title_words) > 1 else ""
        svg = f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 360 500" width="360" height="500">
  <defs>
    <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="{item['bg1']}"/>
      <stop offset="100%" stop-color="{item['bg2']}"/>
    </linearGradient>
    <linearGradient id="glow" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="{item['accent']}"/>
      <stop offset="100%" stop-color="{item['accent2']}"/>
    </linearGradient>
  </defs>
  <rect width="360" height="500" rx="18" fill="url(#bg)"/>
  <rect x="12" y="12" width="336" height="476" rx="12" fill="none" stroke="{item['accent']}" stroke-opacity="0.35" stroke-width="1.5"/>
  <rect x="26" y="26" width="66" height="24" rx="6" fill="{item['accent']}" fill-opacity="0.2" stroke="{item['accent']}" stroke-width="1"/>
  <text x="59" y="42" text-anchor="middle" fill="#ffffff" font-family="Segoe UI, Arial, sans-serif" font-size="11" font-weight="700">{item['rating']}</text>
  <rect x="272" y="26" width="62" height="24" rx="6" fill="#000000" fill-opacity="0.45" stroke="{item['accent2']}" stroke-width="1"/>
  <text x="303" y="42" text-anchor="middle" fill="{item['accent2']}" font-family="Segoe UI, Arial, sans-serif" font-size="11" font-weight="700">&#9733; {item['score']}</text>
  {motif_markup}
  <text x="180" y="346" text-anchor="middle" fill="{item['accent']}" font-family="Segoe UI, Arial, sans-serif" font-size="11" font-weight="700" letter-spacing="2.5">{item['genre']}</text>
  <text x="180" y="388" text-anchor="middle" fill="#ffffff" font-family="Segoe UI, Impact, Arial, sans-serif" font-size="30" font-weight="900" letter-spacing="1.5">{line1}</text>
  <text x="180" y="422" text-anchor="middle" fill="url(#glow)" font-family="Segoe UI, Impact, Arial, sans-serif" font-size="30" font-weight="900" letter-spacing="1.5">{line2}</text>
  <line x1="70" y1="438" x2="290" y2="438" stroke="#ffffff" stroke-opacity="0.2" stroke-width="1"/>
  <text x="180" y="460" text-anchor="middle" fill="#cbd5e1" font-family="Segoe UI, Arial, sans-serif" font-size="10.5" font-weight="600" letter-spacing="1.8">{item['subtitle']}</text>
</svg>
"""
        (output_dir / item["filename"]).write_text(svg, encoding="utf-8")


if __name__ == "__main__":
    generate_all(Path(__file__).resolve().parent.parent / "static" / "posters")
    print("Generated 12 SVG movie posters.")
