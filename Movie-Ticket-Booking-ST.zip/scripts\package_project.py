"""Package the Movie Ticket Booking System project into a clean ZIP archive."""
from __future__ import annotations

import zipfile
from pathlib import Path

EXCLUDE_DIRS = {"__pycache__", ".pytest_cache", ".venv", "venv", ".git"}
EXCLUDE_SUFFIXES = {".pyc", ".pyo", ".zip"}


def package_project(root: Path, output_zip: Path) -> int:
    count = 0
    with zipfile.ZipFile(output_zip, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for path in sorted(root.rglob("*")):
            if path.is_dir():
                continue
            if any(part in EXCLUDE_DIRS for part in path.parts):
                continue
            if path.suffix.lower() in EXCLUDE_SUFFIXES:
                continue
            if path.resolve() == output_zip.resolve():
                continue
            rel = path.relative_to(root)
            zf.write(path, arcname=str(rel))
            count += 1
    return count


if __name__ == "__main__":
    project_root = Path(__file__).resolve().parent.parent
    zip_path = project_root / "movie_ticket_booking_project.zip"
    files_added = package_project(project_root, zip_path)
    print(f"Created {zip_path.name} with {files_added} files ({zip_path.stat().st_size} bytes).")
