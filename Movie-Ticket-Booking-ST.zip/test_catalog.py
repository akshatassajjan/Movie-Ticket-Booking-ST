"""Structured test case metadata catalog and PDF report generator for CineAuto."""
from __future__ import annotations

from pathlib import Path
from typing import Any

from fpdf import FPDF

TEST_CASE_CATALOG: dict[str, dict[str, str]] = {
    "test_01_auto_selects_movie_without_user_input": {
        "test_id": "TC-01",
        "scenario": "Automatic Movie Selection",
        "description": "Click BOOK MY TICKET and verify the system automatically selects an active movie without user input.",
        "expected_result": "Pipeline step 1 and digital ticket show the automatically selected active movie.",
        "pass_actual": "Movie selected automatically and matched digital ticket title.",
    },
    "test_02_auto_selected_movie_exists_in_catalog": {
        "test_id": "TC-02",
        "scenario": "Automatic Movie Selection",
        "description": "Verify the automatically chosen movie exists in the active /api/movies catalog.",
        "expected_result": "Selected movie title is present in the active movies catalog.",
        "pass_actual": "Selected movie verified against active catalog API.",
    },
    "test_03_auto_selects_highest_rated_unbooked_movie_first": {
        "test_id": "TC-03",
        "scenario": "Automatic Movie Selection",
        "description": "On a fresh database, verify the system prioritizes the highest-rated available movie first.",
        "expected_result": "Quantum Echo (IMDb 9.0) is automatically selected on first booking.",
        "pass_actual": "Quantum Echo selected automatically on initial booking.",
    },
    "test_04_auto_selection_rotates_movies_across_bookings": {
        "test_id": "TC-04",
        "scenario": "Automatic Movie Selection",
        "description": "Trigger 3 consecutive one-click bookings and verify movies rotate cleanly across available titles.",
        "expected_result": "3 distinct movies are selected across 3 consecutive auto-bookings.",
        "pass_actual": "3 distinct movies allocated across consecutive bookings.",
    },
    "test_05_auto_selects_available_theatre": {
        "test_id": "TC-05",
        "scenario": "Automatic Theatre Selection",
        "description": "Verify an available partner theatre and screen format are automatically chosen.",
        "expected_result": "Ticket displays valid theatre name and screen type (IMAX Laser, Dolby Atmos, 4DX, or Standard).",
        "pass_actual": "Valid partner theatre and screen format selected automatically.",
    },
    "test_06_auto_selected_theatre_matches_movie_schedule": {
        "test_id": "TC-06",
        "scenario": "Automatic Theatre Selection",
        "description": "Cross-check the auto-selected theatre against the SQLite showtimes schedule for the selected movie.",
        "expected_result": "Showtime record matches both movie_id and theatre_id.",
        "pass_actual": "SQLite showtimes row verified matching movie_id and theatre_id.",
    },
    "test_07_auto_selects_valid_booking_date": {
        "test_id": "TC-07",
        "scenario": "Automatic Date Selection",
        "description": "Verify the booking date is formatted as YYYY-MM-DD and is not in the past.",
        "expected_result": "ISO date >= today is automatically selected.",
        "pass_actual": "Valid ISO booking date >= today selected automatically.",
    },
    "test_08_auto_selects_earliest_available_date": {
        "test_id": "TC-08",
        "scenario": "Automatic Date Selection",
        "description": "Verify the system picks the earliest available date when seats are open.",
        "expected_result": "Today's date is selected on a fresh schedule.",
        "pass_actual": "Earliest open date (today) selected automatically.",
    },
    "test_09_auto_selects_available_showtime": {
        "test_id": "TC-09",
        "scenario": "Automatic Showtime Selection",
        "description": "Verify an active showtime slot is automatically selected for the chosen date.",
        "expected_result": "Valid showtime slot (e.g., 10:30 AM or 02:15 PM) displayed on ticket.",
        "pass_actual": "Valid active showtime slot selected automatically.",
    },
    "test_10_auto_allocates_two_seats_by_default": {
        "test_id": "TC-10",
        "scenario": "Automatic Seat Allocation",
        "description": "Verify default automatic booking allocates 2 available seats without manual seat picking.",
        "expected_result": "Seat count is 2 and 2 seat labels appear on digital ticket.",
        "pass_actual": "2 available seats allocated automatically.",
    },
    "test_11_auto_allocates_adjacent_seats_in_same_row": {
        "test_id": "TC-11",
        "scenario": "Automatic Seat Allocation",
        "description": "Verify the allocator prefers adjacent seats in the same row on an open showtime.",
        "expected_result": "Seats A1, A2 are allocated automatically.",
        "pass_actual": "Adjacent seats A1, A2 allocated in row A.",
    },
    "test_12_auto_allocates_next_adjacent_pair_when_first_pair_booked": {
        "test_id": "TC-12",
        "scenario": "Automatic Seat Allocation",
        "description": "When A1, A2 are already booked, verify subsequent allocation picks A3, A4.",
        "expected_result": "Next adjacent pair A3, A4 allocated without overlapping A1, A2.",
        "pass_actual": "Next adjacent pair A3, A4 allocated cleanly.",
    },
    "test_13_auto_allocates_non_adjacent_seats_when_no_adjacent_pair_remains": {
        "test_id": "TC-13",
        "scenario": "Automatic Seat Allocation",
        "description": "When only non-adjacent seats A1 and C4 remain open, verify fallback seat allocation succeeds.",
        "expected_result": "Remaining open seats A1 and C4 are allocated.",
        "pass_actual": "Fallback allocator assigned open seats A1, C4.",
    },
    "test_14_auto_skips_fully_booked_showtime_and_picks_next_available": {
        "test_id": "TC-14",
        "scenario": "Automatic Seat Allocation",
        "description": "Mark the first showtime of a movie sold out and verify the system selects the next open showtime.",
        "expected_result": "Sold-out showtime is skipped and next available showtime is chosen.",
        "pass_actual": "Sold-out showtime skipped; next available showtime selected.",
    },
    "test_15_auto_calculates_unit_and_ticket_subtotal": {
        "test_id": "TC-15",
        "scenario": "Automatic Price Calculation",
        "description": "Verify ticket subtotal equals unit_price multiplied by seat_count.",
        "expected_result": "ticket_price == round(unit_price * seat_count, 2).",
        "pass_actual": "Unit price and subtotal matched exact calculation.",
    },
    "test_16_auto_calculates_convenience_fee": {
        "test_id": "TC-16",
        "scenario": "Automatic Price Calculation",
        "description": "Verify convenience fee is automatically calculated at $1.50 per seat.",
        "expected_result": "convenience_fee == round(1.50 * seat_count, 2).",
        "pass_actual": "Convenience fee calculated accurately at $1.50/seat.",
    },
    "test_17_auto_calculates_18_percent_tax": {
        "test_id": "TC-17",
        "scenario": "Automatic Price Calculation",
        "description": "Verify 18% GST tax is automatically computed on subtotal + convenience fee.",
        "expected_result": "tax_amount == round((subtotal + fee) * 0.18, 2).",
        "pass_actual": "18% GST tax computed accurately.",
    },
    "test_18_auto_calculates_grand_total_displayed_on_ticket": {
        "test_id": "TC-18",
        "scenario": "Automatic Price Calculation",
        "description": "Verify grand total on the digital ticket equals subtotal + convenience fee + tax.",
        "expected_result": "total_amount == round(subtotal + fee + tax, 2).",
        "pass_actual": "Grand total verified on digital ticket breakdown.",
    },
    "test_19_auto_pricing_for_single_seat_via_api": {
        "test_id": "TC-19",
        "scenario": "Automatic Price Calculation",
        "description": "Verify pricing calculation accuracy for 1 seat via /api/auto-book.",
        "expected_result": "1 seat booked with $1.50 fee and accurate 18% tax.",
        "pass_actual": "Single-seat pricing verified via API.",
    },
    "test_20_auto_pricing_for_six_seats_via_api": {
        "test_id": "TC-20",
        "scenario": "Automatic Price Calculation",
        "description": "Verify pricing calculation accuracy for 6 seats via /api/auto-book.",
        "expected_result": "6 seats booked with $9.00 fee and accurate 18% tax.",
        "pass_actual": "Six-seat pricing verified via API.",
    },
    "test_21_simulated_payment_completes_automatically": {
        "test_id": "TC-21",
        "scenario": "Automatic Payment Simulation",
        "description": "Verify simulated auto-payment executes and displays PAY-YYYYMMDD-XXXXXXXX with PAID status.",
        "expected_result": "Valid payment ID generated and payment status is PAID.",
        "pass_actual": "Simulated payment completed automatically with PAID status.",
    },
    "test_22_unique_booking_ids_across_multiple_bookings": {
        "test_id": "TC-22",
        "scenario": "Booking Confirmation",
        "description": "Create 5 bookings and verify every booking_id and payment_id is globally unique.",
        "expected_result": "5 unique CINE-... booking IDs and 5 unique PAY-... payment IDs.",
        "pass_actual": "All 5 booking and payment IDs verified unique.",
    },
    "test_23_booking_confirmation_banner_displayed": {
        "test_id": "TC-23",
        "scenario": "Booking Confirmation",
        "description": "Verify confirmation banner appears with success styling and booking ID after one-click booking.",
        "expected_result": "Success status banner visible containing generated booking ID.",
        "pass_actual": "Confirmation banner displayed with booking ID.",
    },
    "test_24_digital_ticket_displays_all_booking_fields": {
        "test_id": "TC-24",
        "scenario": "Booking Confirmation",
        "description": "Verify digital ticket renders poster, CONFIRMED badge, metadata, seats, pricing, and timestamp.",
        "expected_result": "All digital ticket fields populated and visible.",
        "pass_actual": "Digital ticket rendered with complete booking details.",
    },
    "test_25_digital_ticket_renders_barcode_svg": {
        "test_id": "TC-25",
        "scenario": "Booking Confirmation",
        "description": "Verify SVG barcode bars are generated dynamically inside the ticket stub.",
        "expected_result": "Barcode SVG contains >= 10 rendered <rect> elements.",
        "pass_actual": "Dynamic SVG barcode rendered on digital ticket.",
    },
    "test_26_pipeline_updates_all_eight_steps_to_done": {
        "test_id": "TC-26",
        "scenario": "Booking Confirmation",
        "description": "Verify all 8 animated pipeline step cards complete and transition to .done state.",
        "expected_result": "All 8 pipeline steps have class 'done'.",
        "pass_actual": "All 8 animated workflow steps completed cleanly.",
    },
    "test_27_duplicate_seat_booking_prevented_via_api": {
        "test_id": "TC-27",
        "scenario": "Duplicate Booking Prevention",
        "description": "Attempt to reserve already-booked seat A1 on showtime 1 and verify rejection.",
        "expected_result": "Second reservation fails with HTTP 409 Conflict.",
        "pass_actual": "Duplicate seat reservation rejected with HTTP 409.",
    },
    "test_28_partial_seat_overlap_prevented": {
        "test_id": "TC-28",
        "scenario": "Duplicate Booking Prevention",
        "description": "Book B1, B2 and attempt to book overlapping B2, B3; verify atomic rollback leaves B3 open.",
        "expected_result": "Returns HTTP 409 and B3 remains unbooked (is_booked = 0).",
        "pass_actual": "Overlapping request rejected and B3 remained unbooked.",
    },
    "test_29_sequential_auto_bookings_never_assign_duplicate_seats": {
        "test_id": "TC-29",
        "scenario": "Duplicate Booking Prevention",
        "description": "Run 12 sequential auto-bookings and verify zero duplicate (showtime_id, seat_label) allocations.",
        "expected_result": "All allocated (showtime_id, seat_label) pairs are strictly disjoint.",
        "pass_actual": "12 auto-bookings produced zero overlapping seat allocations.",
    },
    "test_30_cancel_booking_from_digital_ticket_button": {
        "test_id": "TC-30",
        "scenario": "Booking Cancellation",
        "description": "Click Cancel This Booking on the digital ticket and verify CANCELLED & REFUNDED updates.",
        "expected_result": "Status badge becomes CANCELLED, payment REFUNDED, button disabled.",
        "pass_actual": "Digital ticket cancelled and payment refunded automatically.",
    },
    "test_31_cancel_booking_from_history_row_button": {
        "test_id": "TC-31",
        "scenario": "Booking Cancellation",
        "description": "Click Cancel Booking inside the booking history row and verify status updates.",
        "expected_result": "History row chip changes to CANCELLED and cancel button is removed.",
        "pass_actual": "History row updated to CANCELLED immediately.",
    },
    "test_32_auto_cancel_latest_button_cancels_newest_confirmed": {
        "test_id": "TC-32",
        "scenario": "Booking Cancellation",
        "description": "With 2 confirmed bookings, click Auto-Cancel Latest Booking and verify only newest is cancelled.",
        "expected_result": "Newest booking becomes CANCELLED; older remains CONFIRMED.",
        "pass_actual": "Latest booking cancelled while earlier booking remained CONFIRMED.",
    },
    "test_33_cancellation_releases_seats_for_rebooking": {
        "test_id": "TC-33",
        "scenario": "Booking Cancellation",
        "description": "Cancel a booking holding A1, A2 and verify those seats can be booked again.",
        "expected_result": "Re-booking A1, A2 after cancellation succeeds with HTTP 201.",
        "pass_actual": "Released seats A1, A2 successfully re-booked.",
    },
    "test_34_double_cancellation_returns_409_error": {
        "test_id": "TC-34",
        "scenario": "Invalid & Unavailable Scenarios",
        "description": "Attempt to cancel an already-cancelled booking and verify HTTP 409 error.",
        "expected_result": "Returns HTTP 409 Conflict with already-cancelled error message.",
        "pass_actual": "Double cancellation rejected with HTTP 409.",
    },
    "test_35_cancel_nonexistent_booking_returns_404": {
        "test_id": "TC-35",
        "scenario": "Invalid & Unavailable Scenarios",
        "description": "Attempt to cancel a nonexistent booking ID and verify HTTP 404.",
        "expected_result": "Returns HTTP 404 Not Found.",
        "pass_actual": "Nonexistent booking cancellation returned HTTP 404.",
    },
    "test_36_get_nonexistent_booking_returns_404": {
        "test_id": "TC-36",
        "scenario": "Invalid & Unavailable Scenarios",
        "description": "Request details for a nonexistent booking ID and verify HTTP 404.",
        "expected_result": "Returns HTTP 404 Not Found.",
        "pass_actual": "Nonexistent booking lookup returned HTTP 404.",
    },
    "test_37_invalid_seat_count_values_rejected": {
        "test_id": "TC-37",
        "scenario": "Invalid & Unavailable Scenarios",
        "description": "Send invalid seat_count values (0, -2, 7, 'two', True) to /api/auto-book.",
        "expected_result": "All invalid payloads rejected with HTTP 400 Bad Request.",
        "pass_actual": "All 5 invalid seat_count payloads returned HTTP 400.",
    },
    "test_38_sold_out_all_showtimes_shows_error_banner_in_ui": {
        "test_id": "TC-38",
        "scenario": "Invalid & Unavailable Scenarios",
        "description": "Mark every seat in SQLite as booked, click BOOK MY TICKET, and verify UI error handling.",
        "expected_result": "Error banner displays unavailable message without UI crash.",
        "pass_actual": "Sold-out state handled gracefully with error banner.",
    },
    "test_39_database_initializes_all_required_tables": {
        "test_id": "TC-39",
        "scenario": "Database Operations",
        "description": "Verify SQLite initializes movies, theatres, showtimes, seats, bookings, and booking_seats tables.",
        "expected_result": "All 6 required tables exist in sqlite_master.",
        "pass_actual": "All 6 SQLite tables verified present.",
    },
    "test_40_database_seeds_at_least_10_movies_and_theatres": {
        "test_id": "TC-40",
        "scenario": "Database Operations",
        "description": "Verify seeded counts of movies (>=10), theatres (>=4), showtimes, and seats.",
        "expected_result": "12 movies, 4 theatres, >=40 showtimes, and 24 seats per showtime.",
        "pass_actual": "Seeded database counts verified accurately.",
    },
    "test_41_booking_persists_across_browser_reload": {
        "test_id": "TC-41",
        "scenario": "Database Operations",
        "description": "Book a ticket in UI, reload the browser page, and verify persistence from SQLite.",
        "expected_result": "Booking remains visible in history and confirmed count stays 1.",
        "pass_actual": "Booking persisted in SQLite across full page reload.",
    },
    "test_42_cancellation_persists_across_browser_reload": {
        "test_id": "TC-42",
        "scenario": "Database Operations",
        "description": "Cancel a ticket in UI, reload the page, and verify CANCELLED state persists.",
        "expected_result": "History displays CANCELLED and cancelled stat stays 1.",
        "pass_actual": "Cancellation state persisted in SQLite across reload.",
    },
    "test_43_unique_constraint_on_booking_seats_table": {
        "test_id": "TC-43",
        "scenario": "Database Operations",
        "description": "Attempt raw SQLite insertion of duplicate (showtime_id, seat_label) into booking_seats.",
        "expected_result": "SQLite raises sqlite3.IntegrityError.",
        "pass_actual": "UNIQUE(showtime_id, seat_label) raised IntegrityError.",
    },
    "test_44_unique_constraint_on_booking_id_column": {
        "test_id": "TC-44",
        "scenario": "Database Operations",
        "description": "Attempt raw SQLite insertion of duplicate booking_id into bookings table.",
        "expected_result": "SQLite raises sqlite3.IntegrityError.",
        "pass_actual": "UNIQUE(booking_id) raised IntegrityError.",
    },
    "test_45_seat_availability_count_decrements_and_increments": {
        "test_id": "TC-45",
        "scenario": "Database Operations",
        "description": "Verify /api/system-status available_seats drops by 2 on booking and restores by 2 on cancel.",
        "expected_result": "Available seats decrement on booking and increment on cancellation.",
        "pass_actual": "Seat availability counter updated accurately across lifecycle.",
    },
    "test_46_invalid_json_body_rejected_cleanly": {
        "test_id": "TC-46",
        "scenario": "Database Operations",
        "description": "Submit non-dict JSON and invalid field types to booking API endpoints.",
        "expected_result": "Endpoints return HTTP 400 Bad Request.",
        "pass_actual": "Malformed API JSON payloads rejected with HTTP 400.",
    },
    "test_47_homepage_loads_with_title_and_zero_console_errors": {
        "test_id": "TC-47",
        "scenario": "UI & Navigation",
        "description": "Load homepage and monitor browser console and pageerror events.",
        "expected_result": "Title matches CineAuto and zero JS console/page errors occur.",
        "pass_actual": "Homepage loaded cleanly with zero JS errors.",
    },
    "test_48_at_least_10_movies_displayed_with_details": {
        "test_id": "TC-48",
        "scenario": "UI & Navigation",
        "description": "Verify movie catalog grid renders at least 10 movie cards with title, price, and seat availability.",
        "expected_result": ">=10 movie cards rendered with full details.",
        "pass_actual": "12 movie cards displayed with pricing and availability.",
    },
    "test_49_all_movie_posters_load_cleanly": {
        "test_id": "TC-49",
        "scenario": "UI & Navigation",
        "description": "Check every poster image in #movies-grid for complete load and naturalWidth > 0.",
        "expected_result": "All 12 SVG posters render with naturalWidth > 0.",
        "pass_actual": "All 12 movie posters loaded without broken images.",
    },
    "test_50_zero_manual_selection_controls_in_ui": {
        "test_id": "TC-50",
        "scenario": "UI & Navigation",
        "description": "Audit the entire DOM to confirm zero <select>, <input>, <textarea>, or <form> elements exist.",
        "expected_result": "Counts of select, input, textarea, and form are all 0.",
        "pass_actual": "Zero manual selection controls verified in DOM.",
    },
    "test_51_only_one_booking_action_button_book_my_ticket": {
        "test_id": "TC-51",
        "scenario": "UI & Navigation",
        "description": "Verify the hero CTA contains a single enabled button labeled BOOK MY TICKET.",
        "expected_result": "One visible, enabled BOOK MY TICKET button present.",
        "pass_actual": "Single BOOK MY TICKET CTA verified.",
    },
    "test_52_navbar_anchor_navigation_links_work": {
        "test_id": "TC-52",
        "scenario": "UI & Navigation",
        "description": "Click all navbar anchor links and verify corresponding page sections remain visible.",
        "expected_result": "All navbar links scroll/navigate cleanly to their sections.",
        "pass_actual": "All navbar anchor links navigated cleanly.",
    },
    "test_53_booking_history_view_ticket_button_loads_ticket": {
        "test_id": "TC-53",
        "scenario": "UI & Navigation",
        "description": "Click View Ticket on a historical booking row and verify digital ticket updates.",
        "expected_result": "Digital ticket displays the selected historical booking's ID and movie.",
        "pass_actual": "View Ticket loaded selected booking into digital ticket card.",
    },
    "test_54_live_stats_cards_update_after_book_and_cancel": {
        "test_id": "TC-54",
        "scenario": "UI & Navigation",
        "description": "Verify live dashboard stat counters update immediately after booking and cancellation without reload.",
        "expected_result": "Confirmed, cancelled, and available seat counters update live.",
        "pass_actual": "Live inventory counters updated in real time.",
    },
    "test_55_auto_cancel_latest_when_empty_shows_error_banner": {
        "test_id": "TC-55",
        "scenario": "UI & Navigation",
        "description": "Click Auto-Cancel Latest Booking when no bookings exist and verify friendly error banner.",
        "expected_result": "Error banner displays cleanly without JS errors.",
        "pass_actual": "Empty-history auto-cancel displayed friendly error banner.",
    },
    "test_56_responsive_mobile_viewport_renders_without_horizontal_overflow": {
        "test_id": "TC-56",
        "scenario": "UI & Navigation",
        "description": "Render site at 375x812 mobile viewport and verify zero horizontal overflow.",
        "expected_result": "scrollWidth - innerWidth <= 2px and CTA visible.",
        "pass_actual": "Mobile layout rendered cleanly with zero horizontal overflow.",
    },
    "test_57_testing_dashboard_displays_summary_metrics": {
        "test_id": "TC-57",
        "scenario": "Testing Results Dashboard",
        "description": "Verify Testing Results Dashboard shows total, passed, failed, skipped counts, pass %, and action buttons.",
        "expected_result": "All 5 summary KPI cards and Run/HTML/PDF buttons are visible.",
        "pass_actual": "Summary KPIs and report action buttons rendered properly.",
    },
    "test_58_testing_dashboard_lists_all_individual_test_cases": {
        "test_id": "TC-58",
        "scenario": "Testing Results Dashboard",
        "description": "Verify all 50+ individual test cases appear in the dashboard table with status indicators and timings.",
        "expected_result": "Table renders >= 50 rows with ID, scenario, description, expected, actual, status, and duration.",
        "pass_actual": "All individual test cases rendered in detailed results table.",
    },
    "test_59_testing_dashboard_view_details_modal_opens": {
        "test_id": "TC-59",
        "scenario": "Testing Results Dashboard",
        "description": "Click View Details on a test row and verify individual test case details modal opens and closes.",
        "expected_result": "Modal displays full test metadata, expected/actual results, and closes cleanly.",
        "pass_actual": "Test case details modal opened and closed cleanly.",
    },
    "test_60_downloadable_html_and_pdf_reports_return_valid_files": {
        "test_id": "TC-60",
        "scenario": "Testing Results Dashboard",
        "description": "Verify /api/tests/report/html and /api/tests/report/pdf return valid downloadable HTML and PDF files.",
        "expected_result": "HTTP 200 with HTML document and valid %PDF- binary payload.",
        "pass_actual": "Downloadable HTML and PDF test reports verified.",
    },
}


def build_default_results() -> dict[str, Any]:
    """Return initial catalog structure before/when no JSON report exists yet."""
    cases = []
    for fn_name, meta in TEST_CASE_CATALOG.items():
        cases.append(
            {
                "test_id": meta["test_id"],
                "function_name": fn_name,
                "scenario": meta["scenario"],
                "description": meta["description"],
                "expected_result": meta["expected_result"],
                "actual_result": "Not executed yet.",
                "status": "SKIPPED",
                "duration_sec": 0.0,
                "failure_reason": "",
                "screenshot_url": "",
            }
        )
    total = len(cases)
    return {
        "total": total,
        "passed": 0,
        "failed": 0,
        "skipped": total,
        "pass_percentage": 0.0,
        "total_duration_sec": 0.0,
        "executed_at": "Pending execution",
        "cases": cases,
    }


def _safe_text(value: str) -> str:
    return (
        str(value)
        .replace("\u2014", "-")
        .replace("\u2013", "-")
        .replace("\u2022", "*")
        .encode("latin-1", "replace")
        .decode("latin-1")
    )


def generate_pdf_report(results: dict[str, Any], output_path: Path) -> Path:
    """Generate a formatted multi-page PDF test execution report from results dict."""
    output_path.parent.mkdir(parents=True, exist_ok=True)
    pdf = FPDF(orientation="L", unit="mm", format="A4")
    pdf.set_auto_page_break(auto=True, margin=12)
    pdf.add_page()

    # Header
    pdf.set_fill_color(15, 23, 42)
    pdf.rect(0, 0, 297, 24, style="F")
    pdf.set_text_color(248, 250, 252)
    pdf.set_font("Helvetica", "B", 15)
    pdf.set_xy(10, 6)
    pdf.cell(0, 7, "CineAuto - Playwright Automated Testing Results Report", new_x="LMARGIN", new_y="NEXT")
    pdf.set_font("Helvetica", "", 9)
    pdf.set_x(10)
    pdf.cell(
        0,
        5,
        _safe_text(f"Executed At: {results.get('executed_at', '-')}   |   Duration: {results.get('total_duration_sec', 0)}s"),
    )

    # Summary Row
    pdf.set_y(29)
    summary_items = [
        ("Total Tests", str(results.get("total", 0)), (30, 41, 59)),
        ("Passed", str(results.get("passed", 0)), (16, 185, 129)),
        ("Failed", str(results.get("failed", 0)), (239, 68, 68)),
        ("Skipped", str(results.get("skipped", 0)), (234, 179, 8)),
        ("Pass Rate", f"{results.get('pass_percentage', 0)}%", (56, 189, 248)),
    ]
    x = 10
    for label, val, rgb in summary_items:
        pdf.set_fill_color(*rgb)
        pdf.set_text_color(255, 255, 255)
        pdf.rect(x, 29, 52, 15, style="F")
        pdf.set_xy(x + 2, 30.5)
        pdf.set_font("Helvetica", "", 8)
        pdf.cell(48, 5, label)
        pdf.set_xy(x + 2, 35.5)
        pdf.set_font("Helvetica", "B", 12)
        pdf.cell(48, 7, val)
        x += 55.5

    pdf.set_y(50)

    col_widths = [16, 42, 74, 58, 55, 16, 16]
    headers = ["ID", "Scenario", "Description", "Expected Result", "Actual Result", "Status", "Time"]

    def draw_table_header() -> None:
        pdf.set_fill_color(30, 41, 59)
        pdf.set_text_color(255, 255, 255)
        pdf.set_font("Helvetica", "B", 8)
        for w, h in zip(col_widths, headers):
            pdf.cell(w, 7, h, border=1, fill=True, align="C")
        pdf.ln()

    draw_table_header()

    for case in results.get("cases", []):
        if pdf.get_y() > 186:
            pdf.add_page()
            draw_table_header()

        status = case.get("status", "SKIPPED")
        if status == "PASS":
            status_rgb = (22, 163, 74)
        elif status == "FAIL":
            status_rgb = (220, 38, 38)
        else:
            status_rgb = (202, 138, 4)

        pdf.set_font("Helvetica", "", 7.2)
        pdf.set_text_color(15, 23, 42)

        vals = [
            _safe_text(case.get("test_id", "")),
            _safe_text(case.get("scenario", ""))[:32],
            _safe_text(case.get("description", ""))[:58],
            _safe_text(case.get("expected_result", ""))[:46],
            _safe_text(case.get("actual_result", ""))[:44],
            status,
            f"{case.get('duration_sec', 0):.2f}s",
        ]

        row_h = 6.5
        for idx, (w, txt) in enumerate(zip(col_widths, vals)):
            if idx == 5:
                pdf.set_fill_color(*status_rgb)
                pdf.set_text_color(255, 255, 255)
                pdf.set_font("Helvetica", "B", 7.2)
                pdf.cell(w, row_h, txt, border=1, fill=True, align="C")
                pdf.set_text_color(15, 23, 42)
                pdf.set_font("Helvetica", "", 7.2)
            elif idx in (0, 6):
                pdf.cell(w, row_h, txt, border=1, align="C")
            else:
                pdf.cell(w, row_h, txt, border=1)
        pdf.ln()

    pdf.output(str(output_path))
    return output_path
