"""Pytest fixtures for live Flask + SQLite server, Playwright browser, failure screenshots, and JSON/PDF results."""
from __future__ import annotations

import base64
import json
import os
import sys
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Generator

import pytest
from playwright.sync_api import APIRequestContext, Browser, BrowserContext, Page, Playwright, sync_playwright
from werkzeug.serving import make_server

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from app import create_app
from database import init_db
from test_catalog import TEST_CASE_CATALOG, generate_pdf_report

REPORTS_DIR = PROJECT_ROOT / "reports"
SCREENSHOT_DIR = REPORTS_DIR / "screenshots"
RESULTS_JSON_PATH = REPORTS_DIR / "test_results.json"
PDF_REPORT_PATH = REPORTS_DIR / "test_report.pdf"
SCREENSHOT_DIR.mkdir(parents=True, exist_ok=True)

_SESSION_START_TS = time.perf_counter()
_COLLECTED_RESULTS: dict[str, dict[str, Any]] = {}


def _launch_browser(pw: Playwright) -> Browser:
    for kwargs in (
        {"headless": True},
        {"headless": True, "channel": "msedge"},
        {"headless": True, "channel": "chrome"},
    ):
        try:
            return pw.chromium.launch(**kwargs)
        except Exception:
            continue
    return pw.chromium.launch(headless=True)


@pytest.fixture(scope="session")
def playwright_instance() -> Generator[Playwright, None, None]:
    with sync_playwright() as pw:
        yield pw


@pytest.fixture(scope="session")
def browser(playwright_instance: Playwright) -> Generator[Browser, None, None]:
    br = _launch_browser(playwright_instance)
    yield br
    br.close()


@pytest.fixture(scope="session")
def server_handle(tmp_path_factory: pytest.TempPathFactory) -> Generator[dict, None, None]:
    initial_db = tmp_path_factory.mktemp("session_db") / "init.db"
    flask_app = create_app(initial_db)
    server = make_server("127.0.0.1", 0, flask_app, threaded=True)
    port = server.server_port
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    yield {"app": flask_app, "url": f"http://127.0.0.1:{port}"}
    server.shutdown()


@pytest.fixture(scope="function")
def isolated_db(tmp_path: Path, server_handle: dict) -> Path:
    db_path = tmp_path / "test_cinema.db"
    init_db(db_path, seed=True)
    server_handle["app"].config["DB_PATH"] = str(db_path)
    return db_path


@pytest.fixture(scope="function")
def base_url(server_handle: dict, isolated_db: Path) -> str:
    return server_handle["url"]


@pytest.fixture(scope="function")
def context(browser: Browser) -> Generator[BrowserContext, None, None]:
    ctx = browser.new_context(viewport={"width": 1280, "height": 860})
    yield ctx
    ctx.close()


@pytest.fixture(scope="function")
def page(context: BrowserContext) -> Generator[Page, None, None]:
    pg = context.new_page()
    yield pg
    pg.close()


@pytest.fixture(scope="function")
def api_context(
    playwright_instance: Playwright, base_url: str
) -> Generator[APIRequestContext, None, None]:
    req_ctx = playwright_instance.request.new_context(base_url=base_url)
    yield req_ctx
    req_ctx.dispose()


def _extract_concise_failure(rep: pytest.TestReport) -> str:
    text = str(rep.longrepr or "").strip()
    if not text:
        return "Assertion or runtime failure."
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    for ln in reversed(lines):
        if ln.startswith(("E ", "AssertionError", "Error", "playwright.")):
            return ln.lstrip("E ").strip()[:300]
    return lines[-1][:300] if lines else text[:300]


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item: pytest.Item, call: pytest.CallInfo):
    outcome = yield
    rep = outcome.get_result()

    fn_name = item.name.split("[")[0]
    meta = TEST_CASE_CATALOG.get(
        fn_name,
        {
            "test_id": f"TC-{len(_COLLECTED_RESULTS) + 1:02d}",
            "scenario": "Automated Test",
            "description": fn_name.replace("_", " "),
            "expected_result": "Test assertions succeed.",
            "pass_actual": "Test assertions succeeded.",
        },
    )

    screenshot_url = ""
    if rep.when == "call" and rep.failed:
        page = item.funcargs.get("page")
        if page is not None:
            SCREENSHOT_DIR.mkdir(parents=True, exist_ok=True)
            safe_name = item.name.replace("/", "_").replace(":", "_")
            shot_filename = f"{safe_name}.png"
            shot_path = SCREENSHOT_DIR / shot_filename
            try:
                png_bytes = page.screenshot(path=str(shot_path), full_page=True)
                screenshot_url = f"/api/tests/screenshots/{shot_filename}"
                pytest_html = item.config.pluginmanager.getplugin("html")
                if pytest_html is not None:
                    extras = getattr(rep, "extras", [])
                    encoded = base64.b64encode(png_bytes).decode("ascii")
                    extras.append(pytest_html.extras.image(encoded, mime_type="image/png"))
                    rep.extras = extras
            except Exception:
                pass

    if rep.when == "call" or (rep.when in ("setup", "teardown") and (rep.failed or rep.skipped)):
        if rep.skipped:
            status = "SKIPPED"
            actual = "Skipped during test execution."
            failure_reason = str(rep.longrepr[2]) if isinstance(rep.longrepr, tuple) and len(rep.longrepr) > 2 else ""
        elif rep.failed:
            status = "FAIL"
            failure_reason = _extract_concise_failure(rep)
            actual = failure_reason
        else:
            status = "PASS"
            actual = meta["pass_actual"]
            failure_reason = ""

        # Do not overwrite an earlier failure in call with a clean teardown
        existing = _COLLECTED_RESULTS.get(fn_name)
        if existing and existing["status"] == "FAIL" and rep.when == "teardown":
            return

        _COLLECTED_RESULTS[fn_name] = {
            "test_id": meta["test_id"],
            "function_name": fn_name,
            "scenario": meta["scenario"],
            "description": meta["description"],
            "expected_result": meta["expected_result"],
            "actual_result": actual,
            "status": status,
            "duration_sec": round(float(rep.duration), 3),
            "failure_reason": failure_reason,
            "screenshot_url": screenshot_url,
        }


def pytest_sessionfinish(session: pytest.Session, exitstatus: int) -> None:
    if not _COLLECTED_RESULTS:
        return

    cases = sorted(_COLLECTED_RESULTS.values(), key=lambda c: c["test_id"])
    total = len(cases)
    passed = sum(1 for c in cases if c["status"] == "PASS")
    failed = sum(1 for c in cases if c["status"] == "FAIL")
    skipped = sum(1 for c in cases if c["status"] == "SKIPPED")
    pass_pct = round((passed / total) * 100, 1) if total > 0 else 0.0
    total_duration = round(time.perf_counter() - _SESSION_START_TS, 2)

    payload = {
        "total": total,
        "passed": passed,
        "failed": failed,
        "skipped": skipped,
        "pass_percentage": pass_pct,
        "total_duration_sec": total_duration,
        "executed_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "cases": cases,
    }

    REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    tmp_json = REPORTS_DIR / "test_results.json.tmp"
    tmp_json.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    os.replace(tmp_json, RESULTS_JSON_PATH)

    try:
        generate_pdf_report(payload, PDF_REPORT_PATH)
    except Exception:
        pass
