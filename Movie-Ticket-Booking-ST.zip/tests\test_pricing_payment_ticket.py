"""Playwright tests for automatic pricing, taxes, simulated payment, and digital ticket output."""
from __future__ import annotations

import re

from playwright.sync_api import APIRequestContext, Page, expect


def _book_via_ui(page: Page, base_url: str) -> None:
    page.goto(base_url, wait_until="networkidle")
    page.click("#book-my-ticket-btn")
    expect(page.locator("#digital-ticket-card")).to_be_visible(timeout=10000)
    expect(page.locator("#pipeline-state-label")).to_contain_text("Completed", timeout=10000)


def test_15_auto_calculates_unit_and_ticket_subtotal(page: Page, base_url: str) -> None:
    _book_via_ui(page, base_url)
    seat_count = int(page.locator("#ticket-seat-count").inner_text().strip())
    unit_price = float(page.locator("#ticket-unit-price").inner_text().strip())
    subtotal = float(page.locator("#ticket-subtotal").inner_text().replace("$", "").strip())
    assert round(unit_price * seat_count, 2) == subtotal


def test_16_auto_calculates_convenience_fee(page: Page, base_url: str) -> None:
    _book_via_ui(page, base_url)
    seat_count = int(page.locator("#ticket-seat-count").inner_text().strip())
    fee = float(page.locator("#ticket-fee").inner_text().replace("$", "").strip())
    assert fee == round(1.50 * seat_count, 2)


def test_17_auto_calculates_18_percent_tax(page: Page, base_url: str) -> None:
    _book_via_ui(page, base_url)
    subtotal = float(page.locator("#ticket-subtotal").inner_text().replace("$", "").strip())
    fee = float(page.locator("#ticket-fee").inner_text().replace("$", "").strip())
    tax = float(page.locator("#ticket-tax").inner_text().replace("$", "").strip())
    assert tax == round((subtotal + fee) * 0.18, 2)


def test_18_auto_calculates_grand_total_displayed_on_ticket(page: Page, base_url: str) -> None:
    _book_via_ui(page, base_url)
    subtotal = float(page.locator("#ticket-subtotal").inner_text().replace("$", "").strip())
    fee = float(page.locator("#ticket-fee").inner_text().replace("$", "").strip())
    tax = float(page.locator("#ticket-tax").inner_text().replace("$", "").strip())
    total = float(page.locator("#ticket-total").inner_text().replace("$", "").strip())
    assert total == round(subtotal + fee + tax, 2)


def test_19_auto_pricing_for_single_seat_via_api(api_context: APIRequestContext) -> None:
    res = api_context.post("/api/auto-book", data={"seat_count": 1})
    assert res.status == 201
    b = res.json()["booking"]
    assert b["seat_count"] == 1
    assert b["convenience_fee"] == 1.50
    assert b["tax_amount"] == round((b["ticket_price"] + 1.50) * 0.18, 2)
    assert b["total_amount"] == round(b["ticket_price"] + 1.50 + b["tax_amount"], 2)


def test_20_auto_pricing_for_six_seats_via_api(api_context: APIRequestContext) -> None:
    res = api_context.post("/api/auto-book", data={"seat_count": 6})
    assert res.status == 201
    b = res.json()["booking"]
    assert b["seat_count"] == 6
    assert len(b["seats"]) == 6
    assert b["convenience_fee"] == 9.00
    assert b["tax_amount"] == round((b["ticket_price"] + 9.00) * 0.18, 2)


def test_21_simulated_payment_completes_automatically(page: Page, base_url: str) -> None:
    _book_via_ui(page, base_url)
    payment_id = page.locator("#ticket-payment-id").inner_text().strip()
    payment_status = page.locator("#ticket-payment-status").inner_text().strip()
    assert re.match(r"^PAY-\d{8}-[A-F0-9]{8}$", payment_id)
    assert payment_status == "PAID"


def test_22_unique_booking_ids_across_multiple_bookings(api_context: APIRequestContext) -> None:
    booking_ids = set()
    payment_ids = set()
    for _ in range(5):
        res = api_context.post("/api/auto-book", data={})
        assert res.status == 201
        b = res.json()["booking"]
        assert re.match(r"^CINE-\d{8}-[A-F0-9]{8}$", b["booking_id"])
        assert re.match(r"^PAY-\d{8}-[A-F0-9]{8}$", b["payment_id"])
        booking_ids.add(b["booking_id"])
        payment_ids.add(b["payment_id"])
    assert len(booking_ids) == 5
    assert len(payment_ids) == 5


def test_23_booking_confirmation_banner_displayed(page: Page, base_url: str) -> None:
    _book_via_ui(page, base_url)
    banner = page.locator("#status-banner")
    expect(banner).to_be_visible()
    assert "success" in (banner.get_attribute("class") or "")
    booking_id = page.locator("#ticket-booking-id").inner_text().strip()
    assert booking_id in banner.inner_text()


def test_24_digital_ticket_displays_all_booking_fields(page: Page, base_url: str) -> None:
    _book_via_ui(page, base_url)
    assert page.locator("#ticket-empty-state").is_hidden()
    assert page.locator("#ticket-status-badge").inner_text().strip() == "CONFIRMED"
    assert page.locator("#ticket-poster").get_attribute("src").endswith(".svg")
    assert page.locator("#stub-seat-count").inner_text().strip() == "2"
    assert "Booked:" in page.locator("#ticket-created-at").inner_text()


def test_25_digital_ticket_renders_barcode_svg(page: Page, base_url: str) -> None:
    _book_via_ui(page, base_url)
    bars_count = page.locator("#ticket-barcode rect").count()
    assert bars_count >= 10


def test_26_pipeline_updates_all_eight_steps_to_done(page: Page, base_url: str) -> None:
    _book_via_ui(page, base_url)
    done_steps = page.locator("#booking-progress-panel .pipeline-step.done").count()
    assert done_steps == 8
