# Test Execution Summary — CineAuto Movie Ticket Booking System

## Execution Overview
- **Test Runner:** `pytest 9.2.0` with `playwright 1.65.2` (Chromium headless) and `pytest-html 4.2.0`
- **Python Version:** `3.10.1` (`win32`)
- **Total Automated Test Cases:** **60**
- **Passed:** **60**
- **Failed:** **0**
- **Skipped:** **0**
- **Pass Percentage:** **100.0%**
- **Execution Duration:** `89.71s (0:01:29)`
- **HTML Report:** [`reports/test_report.html`](../reports/test_report.html)
- **PDF Report:** [`reports/test_report.pdf`](../reports/test_report.pdf)
- **JSON Dashboard Data:** [`reports/test_results.json`](../reports/test_results.json)
- **Manual Test Cases:** [`docs/MANUAL_TEST_CASES.md`](MANUAL_TEST_CASES.md)
- **Failure Screenshots Directory:** [`reports/screenshots/`](../reports/screenshots/)

---

## Coverage Breakdown by Module

| Test Module | Scope Covered | Total | Passed | Failed |
|---|---|---:|---:|---:|
| `tests/test_auto_selection.py` | Automatic movie, theatre, date, showtime & seat selection | 14 | 14 | 0 |
| `tests/test_pricing_payment_ticket.py` | Automatic pricing, 18% GST tax, simulated payment, unique IDs & digital ticket | 12 | 12 | 0 |
| `tests/test_duplicates_cancellation.py` | Duplicate seat prevention, cancellation, seat release & invalid/sold-out cases | 12 | 12 | 0 |
| `tests/test_database_integrity.py` | SQLite schema, seeding, constraints & reload persistence | 8 | 8 | 0 |
| `tests/test_ui_navigation.py` | 12 movies, SVG posters, zero manual controls, navigation, mobile layout & Testing Dashboard | 14 | 14 | 0 |
| **Total** | **All Functional, Database, API, UI & Dashboard Requirements** | **60** | **60** | **0** |

---

## Defect Found & Fixed During Testing
1. **Initial Run Defect (`TC-56`)**: `test_56_responsive_mobile_viewport_renders_without_horizontal_overflow` failed on the first run (`scrollWidth - innerWidth = 63px` on `375x812` mobile viewport).
   - **Evidence Captured**: Automatic full-page failure screenshot saved at `reports/screenshots/test_56_responsive_mobile_viewport_renders_without_horizontal_overflow.png`.
   - **Root Cause**: Unwrapped `.nav-links` and 3-column `.stats-grid` under `640px` viewport width.
   - **Fix Applied**: Added responsive wrapping rules inside `@media (max-width: 640px)` in `static/css/style.css`.
   - **Verification**: Full 60-test Playwright suite re-executed after fix — **60/60 PASSED (100.0%)**.
