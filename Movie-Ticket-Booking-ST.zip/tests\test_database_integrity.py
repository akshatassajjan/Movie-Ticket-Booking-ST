"""Playwright and SQLite tests for database schema, persistence, constraints, and status integrity."""
from __future__ import annotations

import sqlite3

from playwright.sync_api import APIRequestContext, Page, expect

from database import get_connection


def test_39_database_initializes_all_required_tables(isolated_db) -> None:
    conn = get_connection(isolated_db)
    try:
        tables = {
            r[0]
            for r in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            ).fetchall()
        }
        assert {"movies", "theatres", "showtimes", "seats", "bookings", "booking_seats"}.issubset(
            tables
        )
    finally:
        conn.close()


def test_40_database_seeds_at_least_10_movies_and_theatres(isolated_db) -> None:
    conn = get_connection(isolated_db)
    try:
        movies = conn.execute("SELECT COUNT(*) FROM movies").fetchone()[0]
        theatres = conn.execute("SELECT COUNT(*) FROM theatres").fetchone()[0]
        showtimes = conn.execute("SELECT COUNT(*) FROM showtimes").fetchone()[0]
        seats = conn.execute("SELECT COUNT(*) FROM seats").fetchone()[0]
        assert movies >= 10
        assert theatres >= 4
        assert showtimes >= 40
        assert seats == showtimes * 24
    finally:
        conn.close()


def test_41_booking_persists_across_browser_reload(page: Page, base_url: str) -> None:
    page.goto(base_url, wait_until="networkidle")
    page.click("#book-my-ticket-btn")
    expect(page.locator("#digital-ticket-card")).to_be_visible(timeout=10000)
    booking_id = page.locator("#ticket-booking-id").inner_text().strip()

    page.reload(wait_until="networkidle")
    expect(page.locator(f".history-item[data-booking-id='{booking_id}']")).to_be_visible()
    expect(page.locator("#stat-confirmed")).to_have_text("1")


def test_42_cancellation_persists_across_browser_reload(page: Page, base_url: str) -> None:
    page.goto(base_url, wait_until="networkidle")
    page.click("#book-my-ticket-btn")
    expect(page.locator("#digital-ticket-card")).to_be_visible(timeout=10000)
    booking_id = page.locator("#ticket-booking-id").inner_text().strip()
    page.click("#ticket-cancel-btn")
    expect(page.locator("#ticket-status-badge")).to_have_text("CANCELLED")

    page.reload(wait_until="networkidle")
    expect(
        page.locator(f".history-item[data-booking-id='{booking_id}'] .status-chip")
    ).to_have_text("CANCELLED")
    expect(page.locator("#stat-cancelled")).to_have_text("1")


def test_43_unique_constraint_on_booking_seats_table(
    api_context: APIRequestContext, isolated_db
) -> None:
    booking = api_context.post("/api/auto-book", data={}).json()["booking"]
    conn = get_connection(isolated_db)
    try:
        raised = False
        try:
            conn.execute(
                "INSERT INTO booking_seats (showtime_id, seat_label, booking_id) VALUES (?, ?, ?)",
                (booking["showtime_id"], booking["seats"][0], booking["booking_id"]),
            )
        except sqlite3.IntegrityError:
            raised = True
        assert raised
    finally:
        conn.close()


def test_44_unique_constraint_on_booking_id_column(
    api_context: APIRequestContext, isolated_db
) -> None:
    booking = api_context.post("/api/auto-book", data={}).json()["booking"]
    conn = get_connection(isolated_db)
    try:
        raised = False
        try:
            conn.execute(
                """
                INSERT INTO bookings (
                    booking_id, movie_id, theatre_id, showtime_id,
                    movie_title, theatre_name, theatre_location, screen_type,
                    show_date, show_time, seat_count, seats_json,
                    unit_price, ticket_price, convenience_fee, tax_amount, total_amount,
                    payment_id, payment_method, payment_status, booking_status, created_at
                ) VALUES (?, ?, ?, ?, 'X', 'T', 'L', 'IMAX', '2026-12-01', '10:30 AM', 1, '["A1"]', 10, 10, 1.5, 2.0, 13.5, 'PAY-DUP-1', 'Card', 'PAID', 'CONFIRMED', '2026-12-01')
                """,
                (
                    booking["booking_id"],
                    booking["movie_id"],
                    booking["theatre_id"],
                    booking["showtime_id"],
                ),
            )
        except sqlite3.IntegrityError:
            raised = True
        assert raised
    finally:
        conn.close()


def test_45_seat_availability_count_decrements_and_increments(
    api_context: APIRequestContext,
) -> None:
    before = api_context.get("/api/system-status").json()["available_seats"]
    b = api_context.post("/api/auto-book", data={}).json()["booking"]
    after_book = api_context.get("/api/system-status").json()["available_seats"]
    assert after_book == before - 2

    api_context.post(f"/api/bookings/{b['booking_id']}/cancel")
    after_cancel = api_context.get("/api/system-status").json()["available_seats"]
    assert after_cancel == before


def test_46_invalid_json_body_rejected_cleanly(api_context: APIRequestContext) -> None:
    r1 = api_context.post("/api/auto-book", data=[1, 2, 3])
    assert r1.status == 400

    r2 = api_context.post(
        "/api/bookings/reserve-seats",
        data={"showtime_id": "bad", "seat_labels": ["A1"]},
    )
    assert r2.status == 400
