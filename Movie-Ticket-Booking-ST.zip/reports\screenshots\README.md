# Failure Screenshots Directory

Playwright's `pytest_runtest_makereport` hook in `tests/conftest.py` automatically saves full-page PNG screenshots here whenever any automated test fails during execution, and embeds them into `reports/test_report.html`.

- `test_56_responsive_mobile_viewport_renders_without_horizontal_overflow.png`: Captured during the initial test run when the 375px mobile viewport caught a 63px horizontal overflow in the navbar/stats grid. After updating `@media (max-width: 640px)` in `static/css/style.css`, the full 56-test suite passed 100%.
