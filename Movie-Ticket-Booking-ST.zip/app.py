"""Flask application for the Automatic One-Click Movie Ticket Booking System."""
from __future__ import annotations

import json
import os
import subprocess
import sys
import threading
from datetime import datetime
from pathlib import Path
from typing import Any

from flask import Flask, jsonify, render_template, request, send_file, send_from_directory

from database import (
    BookingError,
    cancel_booking,
    cancel_latest_booking,
    get_booking,
    get_system_status,
    init_db,
    list_bookings,
    list_movies,
    perform_auto_booking,
    reserve_specific_seats,
)
from test_catalog import build_default_results, generate_pdf_report

PROJECT_ROOT = Path(__file__).resolve().parent
REPORTS_DIR = PROJECT_ROOT / "reports"
SCREENSHOT_DIR = REPORTS_DIR / "screenshots"
RESULTS_JSON_PATH = REPORTS_DIR / "test_results.json"
HTML_REPORT_PATH = REPORTS_DIR / "test_report.html"
PDF_REPORT_PATH = REPORTS_DIR / "test_report.pdf"


def load_test_results() -> dict[str, Any]:
    if RESULTS_JSON_PATH.exists():
        try:
            data = json.loads(RESULTS_JSON_PATH.read_text(encoding="utf-8"))
            if isinstance(data, dict) and isinstance(data.get("cases"), list):
                return data
        except Exception:
            pass
    return build_default_results()


def create_app(db_path: str | Path | None = None) -> Flask:
    app = Flask(__name__)
    resolved_db = Path(db_path) if db_path else Path(
        os.environ.get("MOVIE_DB_PATH") or (PROJECT_ROOT / "cinema.db")
    )
    app.config["DB_PATH"] = str(resolved_db)
    init_db(resolved_db, seed=True)

    test_run_lock = threading.Lock()
    test_run_state: dict[str, Any] = {
        "running": False,
        "started_at": None,
        "finished_at": None,
        "last_exit_code": None,
        "message": "Idle",
    }

    def db() -> str:
        return app.config["DB_PATH"]

    @app.get("/")
    def index() -> str:
        movies = list_movies(db())
        status = get_system_status(db())
        bookings = list_bookings(db())
        test_results = load_test_results()
        return render_template(
            "index.html",
            movies=movies,
            status=status,
            bookings=bookings,
            test_results=test_results,
        )

    @app.get("/health")
    def health() -> Any:
        return jsonify({"status": "ok"})

    @app.get("/api/movies")
    def api_movies() -> Any:
        return jsonify({"movies": list_movies(db())})

    @app.get("/api/system-status")
    def api_system_status() -> Any:
        return jsonify(get_system_status(db()))

    @app.post("/api/auto-book")
    def api_auto_book() -> Any:
        payload = request.get_json(silent=True)
        if payload is None:
            payload = {}
        if not isinstance(payload, dict):
            return jsonify({"error": "Invalid JSON body."}), 400

        seat_count = payload.get("seat_count")
        try:
            result = perform_auto_booking(db_path=db(), seat_count=seat_count)
            return jsonify(result), 201
        except BookingError as exc:
            return jsonify({"error": exc.message}), exc.status_code

    @app.get("/api/bookings")
    def api_list_bookings() -> Any:
        return jsonify({"bookings": list_bookings(db())})

    @app.get("/api/bookings/<booking_id>")
    def api_get_booking(booking_id: str) -> Any:
        try:
            booking = get_booking(booking_id, db_path=db())
            return jsonify({"booking": booking})
        except BookingError as exc:
            return jsonify({"error": exc.message}), exc.status_code

    @app.post("/api/bookings/<booking_id>/cancel")
    def api_cancel_booking(booking_id: str) -> Any:
        try:
            booking = cancel_booking(booking_id, db_path=db())
            return jsonify({"booking": booking, "message": "Booking cancelled and seats released."})
        except BookingError as exc:
            return jsonify({"error": exc.message}), exc.status_code

    @app.post("/api/bookings/cancel-latest")
    def api_cancel_latest() -> Any:
        try:
            booking = cancel_latest_booking(db_path=db())
            return jsonify({"booking": booking, "message": "Latest booking cancelled automatically."})
        except BookingError as exc:
            return jsonify({"error": exc.message}), exc.status_code

    @app.post("/api/bookings/reserve-seats")
    def api_reserve_seats() -> Any:
        payload = request.get_json(silent=True)
        if not isinstance(payload, dict):
            return jsonify({"error": "Invalid JSON payload."}), 400
        showtime_id = payload.get("showtime_id")
        seat_labels = payload.get("seat_labels")
        if not isinstance(showtime_id, int) or isinstance(showtime_id, bool):
            return jsonify({"error": "showtime_id must be an integer."}), 400
        if not isinstance(seat_labels, list) or not all(isinstance(s, str) for s in seat_labels):
            return jsonify({"error": "seat_labels must be a list of strings."}), 400
        try:
            booking = reserve_specific_seats(showtime_id, seat_labels, db_path=db())
            return jsonify({"booking": booking}), 201
        except BookingError as exc:
            return jsonify({"error": exc.message}), exc.status_code

    # --- Testing Results Dashboard & Report Endpoints ---

    @app.get("/api/tests/results")
    def api_test_results() -> Any:
        return jsonify(load_test_results())

    @app.get("/api/tests/status")
    def api_test_status() -> Any:
        with test_run_lock:
            return jsonify(dict(test_run_state))

    @app.post("/api/tests/run")
    def api_run_all_tests() -> Any:
        with test_run_lock:
            if test_run_state["running"]:
                return jsonify({"running": True, "message": "Test suite is already executing."}), 409
            test_run_state["running"] = True
            test_run_state["started_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            test_run_state["finished_at"] = None
            test_run_state["last_exit_code"] = None
            test_run_state["message"] = "Executing all Playwright automated test cases..."

        def _worker() -> None:
            exit_code = 1
            msg = "Completed"
            try:
                proc = subprocess.run(
                    [sys.executable, "-m", "pytest"],
                    cwd=str(PROJECT_ROOT),
                    capture_output=True,
                    text=True,
                    timeout=300,
                )
                exit_code = proc.returncode
                msg = (
                    "All tests finished successfully."
                    if exit_code == 0
                    else f"Test suite finished with exit code {exit_code}."
                )
            except Exception as exc:
                msg = f"Test runner error: {exc}"
            finally:
                with test_run_lock:
                    test_run_state["running"] = False
                    test_run_state["finished_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    test_run_state["last_exit_code"] = exit_code
                    test_run_state["message"] = msg

        threading.Thread(target=_worker, daemon=True).start()
        return jsonify({"running": True, "message": "Started all Playwright tests."}), 202

    @app.get("/api/tests/report/html")
    def api_download_html_report() -> Any:
        if not HTML_REPORT_PATH.exists():
            return jsonify({"error": "HTML report not generated yet. Run tests first."}), 404
        return send_file(
            HTML_REPORT_PATH,
            mimetype="text/html",
            as_attachment=True,
            download_name="cineauto_playwright_test_report.html",
        )

    @app.get("/api/tests/report/pdf")
    def api_download_pdf_report() -> Any:
        results = load_test_results()
        generate_pdf_report(results, PDF_REPORT_PATH)
        return send_file(
            PDF_REPORT_PATH,
            mimetype="application/pdf",
            as_attachment=True,
            download_name="cineauto_playwright_test_report.pdf",
        )

    @app.get("/api/tests/screenshots/<path:filename>")
    def api_get_failure_screenshot(filename: str) -> Any:
        return send_from_directory(SCREENSHOT_DIR, filename)

    @app.errorhandler(404)
    def handle_404(_err: Any) -> Any:
        if request.path.startswith("/api/"):
            return jsonify({"error": "Endpoint not found."}), 404
        return render_template(
            "index.html",
            movies=list_movies(db()),
            status=get_system_status(db()),
            bookings=list_bookings(db()),
            test_results=load_test_results(),
        ), 404

    return app


app = create_app()

if __name__ == "__main__":
    host = os.environ.get("HOST", "0.0.0.0")
    port = int(os.environ.get("PORT", "5000"))
    app.run(host=host, port=port, debug=False)
